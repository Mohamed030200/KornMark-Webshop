﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Collections.Generic;
using KornMark.Website.APIClient;
using System.Text.Json;
using RestSharp;
using System.Text;
using KornMark.Website.ApiClient.DTO;
using KornMark.Website.APIClient.DTO;
using System.Diagnostics;
using System.Net;

namespace KornMark.Website.APIClient
{

    public class RestAPIClient : IRestClient
    {
        private readonly RestClient _client;

        public RestAPIClient(string baseApiUrl) => _client = new RestClient(baseApiUrl);


        public int AddSaleItem(SaleItemDto saleItem)
        {
            var request = new RestRequest("SaleItem", Method.Post);
            request.AddJsonBody(saleItem);
            var response = _client.Execute<int>(request);
            return response.Data;
        }


        public IEnumerable<SaleItemDto> Get100SaleItems()
        {

            throw new NotImplementedException();
        }


        public int ConfirmOrder(OrderDto order) 
        {
            var request = new RestRequest("Order", Method.Post);
            request.AddJsonBody(order); 
            var response = _client.Execute<int>(request);
            return response.Data;
        
        }  

        public SaleItemDto GetSaleItemFromId(int id)
        //public async Task<SaleItem> GetSaleItemFromId(int id)
        {
            try
            {
                //var request = new RestRequest($"https://localhost:7165/api/SaleItem/{id}", Method.Get);
                var request = new RestRequest($"SaleItem/{id}", Method.Get);
                var response = _client.Execute<SaleItemDto>(request);
                //if (response.IsSuccessful && response.Data != null)
                //{
                return response.Data;
                //}
                //else
                //{
                //    Console.WriteLine($"Failed to retrieve SaleItem. Status Code: {response.StatusCode}, Error: {response.ErrorMessage}");
                //    return null;
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error while retrieving SaleItem: {ex.Message}");
                return null;
            }

            //    //response.EnsureSuccessStatusCode();
        }


        public IEnumerable<SaleItemDto> GetSaleItems()
        {
            {
                // Initialize the RestClient (typically you should initialize this in the constructor or as a class member)
                //var client = new RestClient("https://localhost:7165/api");

                // Create a RestRequest for the endpoint
                var request = new RestRequest("SaleItem", Method.Get);

                // Execute the request synchronously and get the response
                var response = _client.Execute<List<SaleItemDto>>(request);

                // Check if the response was successful
                if (response.IsSuccessful && response.Data != null)
                {
                    // Return only the first 100 items (or fewer if less than 100 are available)
                    return response.Data.Take(100);
                }
                else
                {
                    // Handle the case when the response is not successful (log, throw exception, etc.)
                    throw new Exception($"Error retrieving sale items: {response.ErrorMessage}");
                }
            }
        }

        //used to be string return type
        public UserDto TryLogin(string email, string password)
        {
            try
            {
                var request = new RestRequest("User/login", Method.Post);
                request.AddJsonBody(new Credentials { Email = email, Password = password });
                var response = _client.Execute<UserDto>(request);
                //var response = _client.Execute<Credentials>(request);
                if (response.IsSuccessful && response.Data != null)
                {
                    return response.Data;
                }
                throw new Exception($"Login failed: {response.ErrorMessage}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Exception in TryLogin: {ex.Message}");
                throw;
            }

            //else
            //{
            //    Console.WriteLine($"API Error: {response.ErrorMessage}");
            //    return null;
            //}
            //return reponse.Data;
        }
        //try
        //{
        //    var request = new RestRequest("User/login", Method.Post);
        //    request.AddJsonBody(new Credentials { Email = email, Password = password });

        //    var response = _client.Execute<RestResponse>(request);
        //    if(response.IsSuccessful)
        //    {
        //        var responseData = JsonSerializer.Deserialize<JsonElement>(response.Content);

        //        if(responseData.TryGetProperty("Email", out var emailProperty))
        //        {
        //            return emailProperty.GetString();
        //        }
        //        else
        //        {
        //            Console.WriteLine("Email property not found in the response.");
        //            throw new Exception("Login failed: Email not found in the response.");
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine($"Login failed with status code: {response.StatusCode}, Error: {response.ErrorMessage}");
        //        throw new Exception($"Login failed: {response.ErrorMessage}");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    Console.WriteLine($"Error during login: {ex.Message}");
        //    throw new Exception($"Error during login for email {email}: {ex.Message}", ex);
        //}

        public string AddUser(UserDto user)
        {
            var request = new RestRequest("User", Method.Post);
            request.AddJsonBody(user);
            var response = _client.Execute<string>(request); //Internal server error here
            return response.Data;
        }

        public async Task<bool> DeleteSaleItem(int id)
        {
            var request = new RestRequest($"SaleItem", Method.Delete);
            request.AddParameter("id", id);
            var response = _client.Execute<int>(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                return true; // Assume API returns the number of rows deleted.
            }
            else
            {
                throw new Exception($"Error deleting SaleItem with ID {id}: {response.ErrorMessage}");
            }

        }

        public void EmptyOrder()
        {
            // If clearing the order involves the API:
            var request = new RestRequest("Order/Empty", Method.Post); // Assuming there's an endpoint for this.
            var response = _client.Execute(request);

            if (!response.IsSuccessful)
            {
                throw new Exception($"Error emptying the order: {response.ErrorMessage}");
            }
        }

        public decimal GetTotal()
        {
            // Assuming the API has an endpoint for retrieving the total price of the current order.
            var request = new RestRequest("Order/Total", Method.Get);
            var response = _client.Execute<decimal>(request);

            if (response.IsSuccessful)
            {
                return response.Data; // Return the total price received from the API.
            }
            else
            {
                throw new Exception($"Error retrieving total: {response.ErrorMessage}");
            }
        }


        public void Update(int productId, int amount)
        {
            try
            {
                var saleItem = new SaleItemDto
                {
                    Id = productId,
                    Name = "updated Name",
                    Category = "updated Category",
                    Description = "Updated description"
                };

                var orderLineDto = new OrderLineDto
                {
                    Amount = amount,
                    SaleItem = saleItem
                };
                var request = new RestRequest($"Order/ChangeAmount/{productId}", Method.Put);
                request.AddJsonBody(orderLineDto); // Send the updated amount in the request body.
                var response = _client.Execute(request);
                if (!response.IsSuccessful)
                {
                    Debug.WriteLine($"Error: {response.StatusCode} - {response.ErrorMessage}");
                    Debug.WriteLine("Response Content: " + response.Content);
                    throw new Exception($"Error updating product with ID {productId}: {response.ErrorMessage}");
                }
                Console.WriteLine($"Product with ID {productId} updated successfully.");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while updating product with ID {productId}: {ex.Message}");
                throw;
            }
        }

        public UserDto GetUserFromEmail(string email)
        {
            // Construct the API endpoint with the email parameter
            var request = new RestRequest($"User/{email}", Method.Get);

            // Execute the REST API call
            var response = _client.Execute<UserDto>(request);

            // Check the response for success and return the data
            if (response.IsSuccessful && response.Data != null)
            {
                return response.Data;
            }
            else
            {
                // Handle errors appropriately
                throw new Exception($"Error retrieving user: {response.ErrorMessage}");
            }
        }


        //    try
        //    {
        //        var request = new RestRequest("api/User", Method.Post);
        //        request.AddJsonBody(user); 
        //        var response = _client.Execute<int>(request);

        //        if(response.IsSuccessful)
        //        {
        //            return response.Data;
        //        }
        //        else
        //        {
        //            throw new Exception($"Error creating user: {response.ErrorMessage}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new ArgumentException("this doesn't work");
        //    }
        //}
    }
}