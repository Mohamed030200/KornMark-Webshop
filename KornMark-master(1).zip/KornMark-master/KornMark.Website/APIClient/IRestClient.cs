﻿using KornMark.Website.ApiClient.DTO;
using KornMark.Website.APIClient.DTO;
using User = KornMark.Website.ApiClient.DTO;

namespace KornMark.Website.APIClient;

public interface IRestClient
{
    IEnumerable<SaleItemDto> Get100SaleItems();
    //Task<SaleItem> GetSaleItemFromId(int id);
    SaleItemDto GetSaleItemFromId(int id);
    int AddSaleItem(SaleItemDto saleItem);
    Task<bool> DeleteSaleItem(int id);
    void EmptyOrder();
    decimal GetTotal();
    void Update(int productId, int amount);
    IEnumerable<SaleItemDto> GetSaleItems();
    string AddUser(UserDto user);
    //string TryLogin(string email, string password);
    UserDto TryLogin(string email, string password);
    int ConfirmOrder(OrderDto order);
    UserDto GetUserFromEmail(string email);

}
