using KornMark.Website.APIClient;
using Microsoft.AspNetCore.Authentication.Cookies; // Ensure this is correct

namespace KornMark.Website
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container
            builder.Services.AddControllersWithViews(); // For MVC Views or Razor Pages

            // Register HttpClient and API Client for communication with WebAPI
            builder.Services.AddHttpClient(); // Automatically register HttpClient for dependency injection

            builder.Services.AddSingleton<IRestClient>((_) => new RestAPIClient("https://localhost:7165/api"));

            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.LoginPath = "/Account/Login";
                    //options.LoginPath = "/Order/ViewOrder";
                    options.LogoutPath = "/Account/Logout";
                    options.AccessDeniedPath = "/Account/AccessDenied";
                });

            var app = builder.Build();

            //Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();  // Serve static files like CSS, JS, Images

            app.UseRouting();

            // Enable authorization (if needed for authentication)
            app.UseAuthentication();
            app.UseAuthorization();

            // Map default controller route: HomeController -> Index action
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            // Run the application
            app.Run();
        }
    }
}
