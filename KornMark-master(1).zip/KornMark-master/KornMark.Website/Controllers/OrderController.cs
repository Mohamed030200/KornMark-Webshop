﻿using KornMark.Website.ApiClient.DTO;
using KornMark.Website.APIClient;
using KornMark.Website.APIClient.DTO;
using KornMark.Website.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text.Json;

namespace KornMark.Website.Controllers;

[Route("[controller]/[action]")]
public class OrderController : Controller
{

    private readonly IRestClient _restClient;

    public OrderController(IRestClient restClient)
    {
        _restClient = restClient;
    }


    // GET: OrderController/Details/5
    public ActionResult Details(int orderNumber)
    {
        //TODO
        //return View(_restClient.getOrderFromOrderNumber(orderNumber));
        return null;
    }



    // GET: OrderController/Create
    public ActionResult Create()
    {
        var order = GetCartFromCookie();
        return View(order);
    }

    // POST: OrderController/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Create(Cart cart)
    {
        try
        {
            //TODO
            return Redirect("/home/index");
        }
        catch
        {
            return View();
        }
    }

    // GET: OrderController/Edit/5
    public ActionResult Edit(int id)
    {
        return View();
    }

    // POST: OrderController/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Edit(int id, IFormCollection collection)
    {
        try
        {
            return RedirectToAction(nameof(Index));
        }
        catch
        {
            return View();
        }
    }

    // GET: OrderController/Delete/5
    public ActionResult Delete(int id)
    {
        Cart cart = GetCartFromCookie();

        _restClient.DeleteSaleItem(id);

        SaveCartToCookie(cart);

        return RedirectToAction("ViewOrder");
    }

    public ActionResult Index()
    {
        return View();
    }

    //Burde knyttes til indkøbskurv icon
    public IActionResult ViewOrder()
    {

        Cart cart = GetCartFromCookie();

        if (cart == null || cart.ProductQuantities.Count == 0)
        {
            return View(new Cart());
        }

        decimal totalPrice = cart.ProductQuantities.Sum(ol => ol.Value.GetTotalPriceForOneOrderLine());
        int itemCount = cart.ProductQuantities.Sum(ol => ol.Value.Quantity);
        string itemName = string.Join(", ", cart.ProductQuantities.Select(ol => ol.Value.Name));
        //int itemCount = order.OrderLines.Count;

        ViewData["TotalPrice"] = totalPrice;
        ViewData["ItemCount"] = itemCount;
        ViewData["Name"] = itemName;

        return View(cart);
    }

    [HttpPost]
    public IActionResult AddToCart(int saleItemId, int amount)
    {
        var saleItem = _restClient.GetSaleItemFromId(saleItemId); // Retrieve productDTO from API

        if (saleItem == null)
        {
            TempData["ErrorMessage"] = "Produktet kunne ikke findes.";
            return RedirectToAction("ViewOrder"); // Redirect to cart page
        }

        Cart cart = GetCartFromCookie();

        // Validate the stock
        int currentAmountInCart = cart.ProductQuantities.ContainsKey(saleItemId) ? cart.ProductQuantities[saleItemId].Quantity : 0;
        int newTotalAmount = currentAmountInCart + amount;
        if (newTotalAmount > saleItem.Stock)
        {
            TempData["ErrorMessage"] = $"Kan ikke tilføje {amount} af {saleItem.Name}. Vi har ikke flere på lager.";
            return RedirectToAction("ViewOrder"); // Redirect to cart page
        }

        // Update the cart and save the changes
        cart = LoadChangeAndSaveCart(cart =>
        {
            if (cart.ProductQuantities.ContainsKey(saleItemId))
            {
                // Update the quantity if the product already exists in the cart
                cart.ProductQuantities[saleItemId].Quantity += amount;
            }
            else
            {
                // Add a new ProductQuantity if the product doesn't exist in the cart
                cart.ProductQuantities[saleItemId] = new ProductQuantity
                {
                    Id = saleItemId,
                    Quantity = amount,
                    Name = saleItem.Name,
                    Price = saleItem.Price,
                };
            }
        });

        SaveCartToCookie(cart);

        return Redirect("/SaleItem/List");
    }


    [HttpPost]
    public ActionResult ConfirmOrder()
    {
        var email = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value; // Ser hvilken mail der er logged in

        // Sørger for at man er logget ind før man kan købe korn
        if (email == null)
        {
            return Redirect("/Account/Login");
        }

        var phone = _restClient.GetUserFromEmail(email).Phone; // Henter user phone som matcher email

        // Retrieve the cart from the cookie
        Cart cart = GetCartFromCookie();
        if (cart == null || cart.ProductQuantities.Count == 0)
        {
            return BadRequest("The cart is empty.");
        }

        // Map the cart to an OrderDto object
        var orderDto = new OrderDto
        {
            PhoneFK = phone,
            Date = DateTime.UtcNow, // Current date for the order
            TotalPrice = cart.GetTotal(),
            OrderLines = cart.ProductQuantities.Values.Select(pq => new OrderLineDto
            {
                SaleItem = new SaleItemDto
                {
                    Id = pq.Id,
                    Name = pq.Name,
                    Price = pq.Price,
                    Description = "null",
                    Category = "null",
                },
                Amount = pq.Quantity,
                Price = pq.Price
            }).ToList()
        };

        // Call the REST client to confirm the order
        var confirmationNumber = _restClient.ConfirmOrder(orderDto);
        EmptyCart();

        // Return a success response with the confirmation number
        return Ok(new { ConfirmationNumber = confirmationNumber });
    }

    private Cart LoadChangeAndSaveCart(Action<Cart> action)
    {
        Cart cart = GetCartFromCookie();
        action(cart);
        ViewBag.Cart = cart;
        SaveCartToCookie(cart);
        return cart;
    }

    public ActionResult RemoveFromCart(int id)
    {
        var cart = LoadChangeAndSaveCart(cart => cart.RemoveProduct(id));
        return RedirectToAction("ViewOrder", cart);
    }

    public ActionResult ChangeAmountOfProductInCart(int id, int quantity)
    {
        var saleItem = _restClient.GetSaleItemFromId(id);

        Cart cart = GetCartFromCookie();

        // Validate the stock
        int currentAmountInCart = cart.ProductQuantities.ContainsKey(id) ? cart.ProductQuantities[id].Quantity : 0;
        int newTotalAmount = currentAmountInCart + quantity;
        if (newTotalAmount > saleItem.Stock)
        {
            TempData["ErrorMessage"] = $"Kan ikke tilføje {quantity} af {saleItem.Name}. Vi har ikke flere på lager.";
            return RedirectToAction("ViewOrder"); // Redirect to cart page
        }
        cart = LoadChangeAndSaveCart(cart => cart.ChangeQuantity(new ProductQuantity(saleItem, quantity, saleItem.Name, saleItem.Price)));
        return RedirectToAction("ViewOrder", cart);
    }
    
    public IActionResult Subtract(int id, int quantity)
    {
        Cart cart = GetCartFromCookie();
        SaleItemDto saleItem = _restClient.GetSaleItemFromId(id);
        if (saleItem == null)
        {
            throw new ArgumentNullException(nameof(saleItem), "The SaleItem could not be found.");
        }

        var orderLine = new OrderLineDto();
        _restClient.Update(saleItem.Id, quantity);

        SaveCartToCookie(cart);

        return RedirectToAction("ViewOrder");
    }

    public IActionResult EmptyOrder()
    {
        Cart cart = GetCartFromCookie();

        _restClient.EmptyOrder();

        SaveCartToCookie(cart);

        return RedirectToAction("ViewOrder");
    }

    private void SaveCartToCookie(Cart cart)
    {
        var cookieOptions = new CookieOptions();
        //cookieOptions.Expires = DateTime.Now.AddDays(1);
        cookieOptions.Expires = DateTime.Now.AddMinutes(30);
        //der vil være EN cookie per domæne med mindre at man har sat en "custom" path
        cookieOptions.Path = "/";
        Response.Cookies.Append("Cart", JsonSerializer.Serialize(cart), cookieOptions);
    }

    private Cart GetCartFromCookie()
    {
        try
        {
            // Attempt to retrieve the "Order" cookie
            if (Request.Cookies.TryGetValue("Cart", out string? cookie))
            {
                if (!string.IsNullOrEmpty(cookie))
                {
                    var cart = JsonSerializer.Deserialize<Cart>(cookie);
                    return cart ?? new Cart();
                    //return JsonSerializer.Deserialize<Order>(cookie) ?? new Order();
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error retrieving order from cookie: {ex.Message}");
        }
        return new Cart();
    }

    public ActionResult EmptyCart()
    {
        var cart = LoadChangeAndSaveCart(cart => cart.EmptyAll());
        return RedirectToAction("ViewOrder", cart);
    }

}
