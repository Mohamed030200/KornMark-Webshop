using KornMark.Website.Models;
using KornMark.Website.APIClient;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace KornMark.Website.Controllers
{
    public class HomeController : Controller
    {
        private readonly IRestClient _restClient;

        // Constructor for dependency injection
        public HomeController(IRestClient restClient)
        {
            _restClient = restClient;  // Assign injected IRestClient
        }

        // Index action where we fetch sale items
        public async Task<IActionResult> Index()
        {
         
            return View();
        }

        // Privacy page (no change needed)
        public IActionResult Privacy()
        {
            return View();
        }

        // Order page (no change needed)
        public IActionResult Order()
        {
            return View();
        }

        // Error handling
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            //return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            var errorViewModel = new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
            };
            return View(errorViewModel);
        }
    }
}
