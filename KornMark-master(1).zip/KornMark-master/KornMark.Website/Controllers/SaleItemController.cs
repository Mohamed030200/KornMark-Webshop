﻿using KornMark.Website.ApiClient.DTO;
using KornMark.Website.APIClient;
using KornMark.Website.APIClient.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace KornMark.Website.Controllers
{
    public class SaleItemController : Controller
    {

        private readonly IRestClient _restClient;

        public SaleItemController(IRestClient client)
        {
            _restClient = client;
        }


        // GET: SaleItemController
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult List(string searchTerm, string categoryFilter)
        {
            // Retrieve the list of SaleItems
            var saleItems = _restClient.GetSaleItems();

            // Retrieve all distinct categories (for dropdown menu)
            var allCategories = saleItems.Select(item => item.Category).Distinct().ToList();

            // Filter by search term if provided
            if (!string.IsNullOrEmpty(searchTerm))
            {
                // Filter the sale items based on the search term
                saleItems = saleItems.Where(item => item.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                item.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                item.Category.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Filter by category if provided
            if (!string.IsNullOrEmpty(categoryFilter))
            {
                saleItems = saleItems.Where(item => item.Category.Equals(categoryFilter, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Pass both the filtered items and the full list of categories to the view
            ViewBag.Categories = allCategories;
            ViewBag.CategoryFilter = categoryFilter;
            ViewBag.SearchTerm = searchTerm;

            return View(saleItems);
        }

        // GET: SaleItemController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // SaleItemController/Create
        //[Authorize(Policy = "FarmerPolicy")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: SaleItemController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[Authorize(Policy = "FarmerPolicy")]
        public async Task<ActionResult> Create(SaleItemDto saleItem)
        {
            var authorityLevelClaim = User.FindFirst("AuthorityLevel");
            if (authorityLevelClaim != null)
            {
                Debug.WriteLine($"AuthorityLevel: {authorityLevelClaim.Value}");
            }
            else
            {
                Debug.WriteLine("No AuthorityLevel claim found.");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            try
            {
                _restClient.AddSaleItem(saleItem);
                return RedirectToAction("List");  // Redirect to the list view after successful creation
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Exception: {ex.Message}");
            }

            return View(saleItem);
        }

        // GET: SaleItemController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SaleItemController/Edit/5
        [HttpPut]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SaleItemController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SaleItemController/Delete/5
        [HttpDelete("{id}")] // Skal måske være HttpPost uden et ID
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                if (!await _restClient.DeleteSaleItem(id))
                {
                    return NotFound();
                }
                else
                {
                    return Ok();
                }
            }
            catch
            {
                throw new Exception("Could not delete the saleItem");
            }
        }
    }
}
