﻿using KornMark.Website.ApiClient.DTO;
using KornMark.Website.APIClient;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KornMark.Website.Controllers;

public class AccountController : Controller
{

    private readonly IRestClient _restClient;

    public AccountController(IRestClient restClient)
    {
        _restClient = restClient;
    }

    [HttpGet]
    public ActionResult Login() => View(); // shows the login form

    //receives the login form on submit
   [HttpPost]
    public IActionResult Login([FromForm] Credentials loginInfo, [FromQuery] string returnUrl)
    {
        try
        {
            //tester hos API'et om login er gyldigt
            //string email
            var user = _restClient.TryLogin(loginInfo.Email, loginInfo.Password);
            //var userDto = _restClient.
            //int userId = _restClient.TryLogin(loginInfo.Email, loginInfo.PasswordHash);
            //i givet fald laver vi cookie
            //email
            if (!string.IsNullOrEmpty(user.Email))
            {
                SignIn(loginInfo);
                TempData["Message"] = $"Du er logget ind som {user.Email} \r\n {user.Name} \r\n {user.Address}";
            }
            else
            {
                TempData["Message"] = "Invalid login";
                return View();
            }

            if (!string.IsNullOrEmpty(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return Redirect("/");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error during login: {ex.Message}");
            TempData["Message"] = "Error occurred during login.";
            return View();
        }
    }


    private async Task SignIn(Credentials user)
    {
        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Email, user.Email),
        };

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var authProperties = new AuthenticationProperties();
        

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity), authProperties);

        TempData["Message"] = $"You are logged in as {user.Email}";
    }

    public async Task<IActionResult> LogOut()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        TempData["Message"] = "You are now logged out.";
        return RedirectToAction("Login");
    }

    // GET: UserController
    public ActionResult Index()
    {
        if(User.Identity.IsAuthenticated)
        {
            ViewData["Message"] = $"Hello, {User.Identity.Name}!";
        }
        else
        {
            ViewData["Message"] = "You are not logged in.";
        }
        return View();
    }

    // GET: UserController/Details/5
    public ActionResult Details(int id)
    {
        return View();
    }

    // GET: UserController/Create
    public ActionResult Create() => View();

    // POST: UserController/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> Create(UserDto user)
    {
        //if(!ModelState.IsValid)
        //{
        //    ModelState.AddModelError(string.Empty, "Please provide valid user details.");
        //    return View(user);
        //}
        try
        {
            var userEmail = await Task.Run(() => _restClient.AddUser(user));

            if (!string.IsNullOrEmpty(userEmail))
            {
                TempData["Message"] = "User created successfully.";
                return RedirectToAction("Login");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Error creating user. Please try again.");
                return View(user);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error during user creation: {ex.Message}");
            ModelState.AddModelError(string.Empty, $"Error during user creation: {ex.Message}");
            return View(user);
        }
    }

    // GET: UserController/Edit/5
    public ActionResult Edit(int id)
    {
        return View();
    }

    // POST: UserController/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Edit(int id, IFormCollection collection)
    {
        try
        {
            return RedirectToAction(nameof(Index));
        }
        catch
        {
            return View();
        }
    }

    // GET: UserController/Delete/5
    public ActionResult Delete(int id)
    {
        return View();
    }

    // POST: UserController/Delete/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Delete(int id, IFormCollection collection)
    {
        try
        {
            return RedirectToAction(nameof(Index));
        }
        catch
        {
            return View();
        }
    }
}
