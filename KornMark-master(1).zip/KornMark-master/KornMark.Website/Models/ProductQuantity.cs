﻿using KornMark.Website.APIClient.DTO;

namespace KornMark.Website.Models;

public class ProductQuantity
{
    public int Id { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string Name { get; set; } = string.Empty;

    public ProductQuantity(SaleItemDto saleItemDto, int quantity, string name, decimal price)
    {
        Id = saleItemDto.Id;
        Price = saleItemDto.Price;
        Name = saleItemDto.Name;
        Quantity = quantity;
    }

    public ProductQuantity()
    {
        
    }

    public decimal GetTotalPriceForOneOrderLine()
    {
        return Price * Quantity;
    }
}
