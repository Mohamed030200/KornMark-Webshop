-- Se en hel order med OrderId 19 f.eks.
SELECT * 
FROM "Order" O
JOIN "OrderLine" OL ON O.orderId = OL.orderId_fk
WHERE O.orderId = 19;


UPDATE SaleItem
SET name = 'Hvede Bundt', stock = 50, price = 29.99, description = 'H�jkvalitets hvede bundt, perfekt til storlandbrug.', saleItemCategoryId_fk = 1
WHERE saleItemId = 1;

UPDATE SaleItem
SET name = '�kologisk Byg', stock = 35, price = 19.49, description = '�kologisk dyrket byg med h�jt n�ringsindhold.', saleItemCategoryId_fk = 2
WHERE saleItemId = 2;

UPDATE SaleItem
SET name = 'Rugkorn', stock = 25, price = 24.99, description = 'Premium rugkorn for fremragende udbytte.', saleItemCategoryId_fk = 3
WHERE saleItemId = 3;

UPDATE SaleItem
SET name = 'Majsfoder', stock = 40, price = 15.00, description = 'Ideelt majsfoder til husdyr.', saleItemCategoryId_fk = 4
WHERE saleItemId = 4;

UPDATE SaleItem
SET name = 'Bygs�d', stock = 100, price = 5.99, description = 'H�jt udbytte bygs�d, perfekt til plantningss�sonen.', saleItemCategoryId_fk = 5
WHERE saleItemId = 5;

UPDATE SaleItemCategory
SET category = 'Hvede', picture = 'wheat_bundle.jpg'
WHERE saleItemCategoryId = 1;

UPDATE SaleItemCategory
SET category = '�kologisk Byg', picture = 'organic_barley.jpg'
WHERE saleItemCategoryId = 2;

UPDATE SaleItemCategory
SET category = 'Rug', picture = 'rye_grain.jpg'
WHERE saleItemCategoryId = 3;

UPDATE SaleItemCategory
SET category = 'Korn', picture = 'korn.jpg'
WHERE saleItemCategoryId = 4;

UPDATE SaleItemCategory
SET category = 'Byg', picture = 'byg.png'
WHERE saleItemCategoryId = 5;

DROP TABLE IF EXISTS OrderLine;
DROP TABLE IF EXISTS SaleItem;
DROP TABLE IF EXISTS [Order];
DROP TABLE IF EXISTS [User];
DROP TABLE IF EXISTS SaleItemCategory;
DROP TABLE IF EXISTS LocationKornMark;