USE [DMA-CSD-S233_10503086];

CREATE TABLE LocationKornMark (
    zipcode INT PRIMARY KEY NOT NULL,
    city NVARCHAR(255) NOT NULL
);

--CREATE TABLE SaleItemCategory (
--    saleItemCategoGryId INT IDENTITY(1,1) PRIMARY KEY,
--    category NVARCHAR(255) NOT NULL,
--    picture NVARCHAR(MAX)
--);

CREATE TABLE [User] (
    phone NVARCHAR(255) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    cvr NVARCHAR(255),
    address NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    passwordHash NVARCHAR(255) NOT NULL,
    authorityLevel INT DEFAULT 1,
    zipcode_fk INT,
    FOREIGN KEY (zipcode_fk) REFERENCES LocationKornMark(zipcode)
);

CREATE TABLE [Order] (
    orderId INT PRIMARY KEY IDENTITY(1,1),
    totalPrice INT NOT NULL,
    date DATE,
    phone_fk NVARCHAR(255),
    FOREIGN KEY (phone_fk) REFERENCES [User](phone)
);

CREATE TABLE SaleItem (
    saleItemId INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    stock INT,
    price FLOAT NOT NULL,
    description NVARCHAR(MAX) NOT NULL,
	category NVARCHAR(255) NOT NULL,
--    saleItemCategoryId_fk INT NOT NULL,
--    FOREIGN KEY (saleItemCategoryId_fk) REFERENCES SaleItemCategory(saleItemCategoryId)
);

CREATE TABLE OrderLine (
    orderLineId INT IDENTITY(1,1) PRIMARY KEY,
    amount INT,
    saleItemId_fk INT NOT NULL,
    orderId_fk INT NOT NULL,
    FOREIGN KEY (saleItemId_fk) REFERENCES SaleItem(saleItemId),
    FOREIGN KEY (orderId_fk) REFERENCES [Order](orderId)
);