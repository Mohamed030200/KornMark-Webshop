USE [DMA-CSD-S233_10503086];

INSERT INTO LocationKornMark (zipcode, city) VALUES
  (1000, 'K�benhavn'),
  (2000, 'Frederiksberg'),
  (3000, 'Helsing�r'),
  (4000, 'Roskilde'),
  (5000, 'Odense'),
  (6000, 'Kolding'),
  (8000, 'Aarhus'),
  (9000, 'Aalborg'),
  (6700, 'Esbjerg'),
  (8900, 'Randers'),
  (8700, 'Horsens'),
  (8800, 'Viborg');

--INSERT INTO SaleItemCategory (category, picture) VALUES 
--('Wheat', 'wheat_bundle.jpg'),
--('Barley', 'organic_barley.jpg'),
--('Rye', 'rye_grain.jpg'),
--('Korn', 'korn.jpg'),
--('Byg', 'byg.png');

INSERT INTO [User] (phone, name, cvr, address, email, passwordHash, authorityLevel, zipcode_fk) VALUES 
('12345678', 'John Doe', 'CVR12345', '123 Elm Street', 'johndoe@example.com', 'john', 1, 1000),
('87654321', 'Jane Smith', 'CVR67890', '456 Oak Street', 'janesmith@example.com', 'jane', 2, 2000),
('21212121', 'Mr. Bean', '69420', 'Highbury', 'mrbean@gmail.com', 'mrbean', 3, 9000);

INSERT INTO [Order] (totalPrice, date, phone_fk) VALUES 
(250, '2024-11-10', '12345678'),
(175, '2024-11-11', '87654321');

INSERT INTO SaleItem (name, stock, price, description, category) VALUES 
('Foderbyg', 50, 4.99, 'Byg er med dens indhold af energi og fibre yderst velegnet i foderblandingen. Fiber-indholdet er med til at forbedre mave- og tarmsundheden.', 'Hvede'),
('Hvede', 35, 30.49, 'H�j-kvalitets. Godt til at bage boller.', 'Byg'),
('Rugkerner', 25, 24.99, 'Rug har et h�jt indhold af kostfibre. Rugmel kan blandes i alt br�d.', 'Rug'),
('Fodermajs', 40, 15.00, 'Ideel som f�de til din ko. Ogs� godt som fodder til dyrene i stalden.', 'Korn'),
('Byg fr�', 100, 5.99, '100% �kologiske byggr�skerner til spiring af byggr�s.', '�ko Byg');

INSERT INTO OrderLine (amount, saleItemId_fk, orderId_fk) VALUES 
(1, 1, 1),  
(2, 2, 1),  
(3, 3, 2); 