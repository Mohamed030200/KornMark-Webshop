﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace KornMark.DAL.DAO;

public class UserDAO : BaseDAO, IUserDAO
{
    private const string INSERT_SQL = @"
    INSERT INTO [User] 
    (phone, name, cvr, address, email, passwordHash, authorityLevel, zipcode_fk) 
    OUTPUT INSERTED.email 
    VALUES 
    (@Phone, @Name, @Cvr, @Address, @Email, @passwordHash, @AuthorityLevel, @ZipcodeFk)";
    private const string LOGIN_SQL = "SELECT email, passwordHash FROM [User] WHERE email = @Email";
    private const string DELETE_SQL = "DELETE FROM [User] WHERE phone = @Phone";
    private const string DELETEORDERLINES_SQL = "DELETE FROM [OrderLine] WHERE orderId_fk IN (SELECT orderId FROM [Order] WHERE phone_fk = @Phone)";
    private const string DELETEORDER_SQL = "DELETE FROM [Order] WHERE phone_fk = @Phone";
    private const string UPDATE_SQL = @"
        UPDATE [User] 
        SET 
            phone = @Phone, 
            name = @Name, 
            cvr = @Cvr, 
            address = @Address, 
            email = @Email, 
            passwordHash = @PasswordHash, 
            authorityLevel = @AuthorityLevel, 
            zipcode_fk = @ZipcodeFk 
        WHERE email = @Email";
    private const string GETALL_SQL = "SELECT * FROM [User]";
    public UserDAO(string connectionString) : base(connectionString)
    {
    }
    public async Task<string> InsertPerson(User user)
    {
        try
        {
            if (user.AuthorityLevel == 0)
            {
                user.AuthorityLevel = 1;
            }
            var passwordHash = BCryptTool.HashPassword(user.PasswordHash);

            var parameters = new
            {
                user.Phone,
                user.Name,
                user.Cvr,
                user.Address,
                user.Email,
                passwordHash,
                user.AuthorityLevel,
                user.ZipcodeFk
            };

            using var connection = CreateConnection();
            return await connection.QuerySingleAsync<string>(INSERT_SQL, parameters);

        }
        catch (Exception ex)
        {

            throw new Exception($"Error inserting user: '{ex.Message}'.", ex);
        }
    }
    //public async Task<string> TryLogin(string email, string password)
    public async Task<string> TryLogin(UserTuple userTuple)
    {
        try
        {
            using var connection = CreateConnection();

            var user = await connection.QueryFirstOrDefaultAsync<User>(LOGIN_SQL, new { userTuple.Email });

            if (user != null && !string.IsNullOrEmpty(user.PasswordHash))
            {
                if (BCryptTool.ValidatePassword(userTuple.Password, user.PasswordHash))
                {
                    return user.Email;
                }
                else
                {
                    throw new Exception("Invalid password.");
                }
            }

            throw new Exception("Invalid email or password.");
        }
        catch (Exception ex)
        {
            throw new Exception($"Error during login for email {userTuple.Email}: '{ex.Message}'.", ex);
        }
    }

    public async Task<bool> Delete(string phone)
    {
        try
        {
            using var connection = CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();
            try
            {
                // Step 1: Delete related order lines
                await connection.ExecuteAsync(DELETEORDERLINES_SQL, new { Phone = phone }, transaction);

                // Step 2: Delete related orders
                await connection.ExecuteAsync(DELETEORDER_SQL, new { Phone = phone }, transaction);

                // Step 3: Delete the user
                var affectedRows = await connection.ExecuteAsync(DELETE_SQL, new { Phone = phone }, transaction);

                // Commit transaction if all deletions succeed
                transaction.Commit();

                return affectedRows > 0;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error deleting user with phone {phone}: '{ex.Message}'.", ex);
        }
    }

    public async Task<IEnumerable<User>> GetAll()
    {
        try
        {
            using var connection = CreateConnection();
            return (await connection.QueryAsync<User>(GETALL_SQL)).ToList();
        }
        catch (Exception ex)
        {
            throw new Exception($"Error getting all users: '{ex.Message}'.", ex);
        }
    }

    public async Task<User> GetUser(string email)
    {
        try
        {
            //This line is needed or else the api takes "@" as "%40"
            //var decodedEmail = email.Contains("%40") ? Uri.UnescapeDataString(email): email;

            var query = "SELECT * FROM [User] WHERE email=@email";
            using var connection = CreateConnection();
            return await connection.QuerySingleOrDefaultAsync<User>(query, new { email });
        }
        catch (Exception ex)
        {
            throw new Exception($"Error getting user with email {email}: '{ex.Message}'.", ex);
        }
    }

    public async Task<bool> Update(User user)
    {
        try
        {
            var passwordHash = BCryptTool.HashPassword(user.PasswordHash);

            var parameters = new
            {
                user.Phone,
                user.Name,
                user.Cvr,
                user.Address,
                user.Email,
                PasswordHash = passwordHash,
                user.AuthorityLevel,
                user.ZipcodeFk
            };
            using var connection = CreateConnection();
            var affectedRows = await connection.ExecuteAsync(UPDATE_SQL, parameters);
            return affectedRows > 0;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error updating user: '{ex.Message}'.", ex);
        }
    }
}
