﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;



namespace KornMark.DAL.DAO;

public class SaleItemsDAO : BaseDAO, ISalesItemsDAO
{
    private const string SELECT_ALL_ITEMS = @"
        SELECT 
            saleItemId AS Id,
            name AS Name,
            stock AS Stock,
            price AS Price,
            description AS Description,
            category AS Category
        FROM SaleItem ";

    private const string SELECT_BY_ID = @"
        SELECT 
            saleItemId AS Id,
            name AS Name,
            stock AS Stock,
            price AS Price,
            description AS Description,
            category AS Category
        FROM SaleItem 
        WHERE saleItemId = @id";

    private const string INSERT_SQL = @"
        INSERT INTO SaleItem (name, stock, price, description, category) 
        OUTPUT INSERTED.saleItemId 
        VALUES (@Name, @Stock, @Price, @Description, @Category)";

    private const string DELETE_SQL = @"
        DELETE FROM SaleItem WHERE SaleItemId = @id";

    public SaleItemsDAO(string connectionString) : base(connectionString)
    {
    }

    public IEnumerable<SaleItem> GetSaleItems()
    {
        using var connection = CreateConnection();
        var saleItems = connection.Query<SaleItem>(SELECT_ALL_ITEMS).ToList();
        foreach (var item in saleItems)
        {
            Console.WriteLine($"Id: {item.Id}, Name: {item.Name}, Description: {item.Description}");
        }
        return saleItems;
    }

    public IEnumerable<SaleItem> GetSaleItem(int id)
    {
        using var connection = CreateConnection();
        return connection.Query<SaleItem>(SELECT_BY_ID, new { id }).ToList(); // Passing Id as a parameter
    }

    public int Insert(SaleItem saleItem)
    {
        using var connection = CreateConnection();
        return connection.QuerySingle<int>(INSERT_SQL, new
        {
            saleItem.Name,
            saleItem.Stock,
            saleItem.Price,
            saleItem.Description,
            saleItem.Category
        });
    }

    public int Delete(int id)
    {
        using var connection = CreateConnection();
        return connection.Execute(DELETE_SQL, new { id });
    }
}
