﻿using Dapper;
using System;
using System.Data;
using System.Linq;

namespace KornMark.DAL.DAO;

public class OrderDAO : BaseDAO, IOrderDAO
{
    private const string CHECK_STOCK_SQL = @"
            SELECT stock
            FROM SaleItem
            WHERE saleItemId = @SaleItemId";

    private const string InsertOrderSql = @"
            INSERT INTO [Order] (totalPrice, date, phone_fk)
            VALUES (@TotalPrice, @Date, @PhoneFK);
            SELECT SCOPE_IDENTITY();";

    private const string InsertOrderLineSql = @"
            INSERT INTO OrderLine (saleItemId_fk, orderId_fk, amount)
            VALUES (@SaleItemId, @OrderId, @Amount);";

    private const string UpdateStockSql = @"
            UPDATE SaleItem
            SET stock = stock - @Amount
            WHERE saleItemId = @SaleItemId AND stock >= @Amount";


    public OrderDAO(string connectionString) : base(connectionString)
    {
    }



    public int Insert(Order order)
    {
        using var connection = CreateConnection();
        connection.Open();

        // Begins transaction with Serializable isolation level (could also be Repeatable-read)
        using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);

        try
        {
            // Checks stock for all items
            foreach (var line in order.OrderLines)
            {
                SaleItem item = line.SaleItem;
                int amount = line.Amount;

                int stock = connection.QueryFirstOrDefault<int>(
                    CHECK_STOCK_SQL,
                    new { SaleItemId = item.Id },
                    transaction
                );
           
                if (stock < amount)
                {
                    throw new Exception($"SaleItem with Id {item.Id} does not have enough stock. Required: {amount}, Available: {stock}");
                }
            }

            Thread.Sleep(7000); // skaber en pause mellem kontrol af lagerbeholding og ordren oprettes

            // Inserts the order and retrieve its ID
            int orderId = connection.ExecuteScalar<int>(
                InsertOrderSql,
                new { order.TotalPrice, order.Date, order.PhoneFK },
                transaction
            );

            //  Inserts each order line
            foreach (var line in order.OrderLines)
            {
                SaleItem item = line.SaleItem;
                int amount = line.Amount;

                connection.Execute(
                    InsertOrderLineSql,
                    new
                    {
                        SaleItemId = item.Id,
                        OrderId = orderId,
                        Amount = amount
                    },
                    transaction
                );
            }

            //  Deducts stock for each SaleItem
            foreach (var orderLine in order.OrderLines)
            {
                var item = orderLine.SaleItem;
                var amount = orderLine.Amount;

                int rowsAffected = connection.Execute(
                    UpdateStockSql,
                    new
                    {
                        SaleItemId = item.Id,
                        Amount = amount
                    },
                    transaction
                );

                if (rowsAffected == 0)
                {
                    throw new Exception($"Failed to update stock for SaleItem with Id {item.Id}. Stock may have changed.");
                }

            }

            //  Commit transaction
            transaction.Commit();
            return orderId;
        }
        catch (Exception ex)
        {
            //  Rollback on failure
            try
            {
                transaction.Rollback();
            }
            catch (Exception rollbackExeption)
            {

                throw new Exception("error while trying to rollback transaction", rollbackExeption);
            }
            Console.WriteLine($"Error inserting order: {ex.Message}");
            return -1; // Indicate failure
        }
    }

   
}
