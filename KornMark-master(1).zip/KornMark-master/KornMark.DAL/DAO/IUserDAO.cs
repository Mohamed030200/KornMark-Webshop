﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KornMark.DAL.DAO;

public interface IUserDAO
{
    Task<string> InsertPerson(User user);
    Task<IEnumerable<User>> GetAll(); // HACK, be careful when getting all data from the database
    Task<User> GetUser(string email);
    Task<bool> Update(User user);
    Task<bool> Delete(string phone);
    Task<string> TryLogin(UserTuple userTuple);
}
