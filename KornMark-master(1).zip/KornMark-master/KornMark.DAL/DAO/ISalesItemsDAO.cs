﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KornMark.DAL.DAO;

public interface ISalesItemsDAO
{
    IEnumerable<SaleItem> GetSaleItems();
    IEnumerable<SaleItem> GetSaleItem(int id);
    int Insert(SaleItem item);
    int Delete(int id);
}
