﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KornMark.DAL.DAO;

public class OrderLine
{
    public SaleItem SaleItem { get; set; }
    public int Amount { get; set; }

    public OrderLine()
    {
    }

    public OrderLine(SaleItem saleItem, int amount)
    {
        SaleItem = saleItem ?? throw new ArgumentNullException(nameof(saleItem), "saleitem cannot be null here");
        Amount = amount;
    }

    /// <summary>
    /// Calculates the total price for this order line, based on the price of the <see cref="SaleItem"/> and the quantity.
    /// </summary>
    /// <returns>The total price as an integer value, calculated as <c>SaleItem.Price * Amount</c>.</returns>
    /// <remarks>
    /// If the <see cref="SaleItem"/> is null, it returns 0 to avoid null reference exceptions.
    /// </remarks>
    public int GetTotalPrice()
    {
        return (int)((SaleItem?.Price ?? 0) * Amount);
    }
}
