﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace KornMark.DAL.DAO;

public class Order
{
    public int OrderNumber { get; set; }

    public DateTime Date;

    public decimal TotalPrice { get; set; }

    /// <summary>
    /// Holds the order lines as a list.
    /// </summary>
    public List<OrderLine> OrderLines { get; set; } = new List<OrderLine>();

    public string PhoneFK { get; set; }


    public Order(List<OrderLine>? orderLines = null)
    {
        if (orderLines != null)
        {
            OrderLines = orderLines;
        }
    }

    /// <summary>
    /// Updates the quantity of an order line if it exists, or adds it if it does not.
    /// Removes the order line if the quantity becomes zero or negative.
    /// </summary>
    /// <param name="orderLine">The <see cref="OrderLine"/> to update or add to the order.</param>
    /// <exception cref="ArgumentNullException">Thrown if <paramref name="orderLine"/> or its <see cref="OrderLine.SaleItem"/> is null.</exception>
    public void ChangeAmount(OrderLine orderLine)
    {
        if (orderLine == null || orderLine.SaleItem == null)
        {
            throw new ArgumentNullException("OrderLine or its SaleItem property cannot be null.");
        }

        var existingLine = OrderLines.FirstOrDefault(ol => ol.SaleItem.Id == orderLine.SaleItem.Id);

        if (existingLine != null)
        {
            // Adjust amount
            existingLine.Amount += orderLine.Amount;

            if (existingLine.Amount <= 0)
            {
                // Remove item if quantity is zero or below
                OrderLines.Remove(existingLine);
            }
        }
        else if (orderLine.Amount > 0)
        {
            // Add new item only if the amount is positive
            OrderLines.Add(orderLine);
        }
    }

    /// <summary>
    /// Removes an order line for the specified product ID if it exists in the order.
    /// </summary>
    /// <param name="productId">The ID of the product to remove from the order.</param>
    public void RemoveSaleItem(int productId)
    {
        var orderLine = OrderLines.FirstOrDefault(ol => ol.SaleItem.Id == productId);
        if (orderLine != null)
        {
            OrderLines.Remove(orderLine);
        }
    }

    /// <summary>
    /// Updates the quantity of the specified product in the order.
    /// </summary>
    /// <param name="productId">The ID of the product to update.</param>
    /// <param name="amount">The new quantity for the product.</param>
    public void Update(int productId, int amount)
    {
        var orderLine = OrderLines.FirstOrDefault(ol => ol.SaleItem.Id == productId);

        if (orderLine != null)
        {
            if (amount <= 0)
            {
                // Remove the item if the amount is zero or negative
                OrderLines.Remove(orderLine);
            }
            else
            {
                // Update the amount
                orderLine.Amount = amount;
            }
        }
    }

    /// <summary>
    /// Calculates the total price of the order by summing up the total price of each order line.
    /// </summary>
    /// <returns>The total price of the order as a decimal.</returns>
    public decimal GetTotal() => OrderLines.Sum(ol => ol.GetTotalPrice());

    /// <summary>
    /// Calculates the total number of products in the order by summing the quantities of all order lines.
    /// </summary>
    /// <returns>The total quantity of all products in the order.</returns>
    public int GetNumberOfProducts() => OrderLines.Sum(ol => ol.Amount);

    /// <summary>
    /// Empties the order by clearing all order lines.
    /// </summary>
    public void EmptyAll() => OrderLines.Clear();
}
