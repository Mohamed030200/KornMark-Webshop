﻿//using KornMark.DAL.DAO;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace KornMark.DAL
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            // Define the connection string to your database
//            string connectionString = "Server=localhost\\SQLEXPRESS; Database=KornMark; Trusted_Connection=true";

//            // Create an instance of OrderDAO
//            OrderDAO orderDAO = new OrderDAO(connectionString);

//            OrderLine line1 = new OrderLine();
//            OrderLine line2 = new OrderLine();

//            Dictionary<int, OrderLine> orderLines = new Dictionary<int, OrderLine>
//            {
//                { 1, line1 },
//                { 2, line2 }
//            };

//            // Create a sample order object
//            Order order = new Order(orderLines);
          

//            // Call the Insert method and capture the result
//            int orderNumber = orderDAO.Insert(order);

//            // Display the result
//            if (orderNumber > 0)
//            {
//                Console.WriteLine($"Order inserted successfully with Order Number: {orderNumber}");
//            }
//            else
//            {
//                Console.WriteLine("Failed to insert the order.");
//            }
//        }
//    }

   
//}

