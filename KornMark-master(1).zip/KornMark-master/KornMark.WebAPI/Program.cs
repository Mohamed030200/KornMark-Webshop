using KornMark.DAL.DAO;
using System.Data.Common;
namespace KornMark.WebAPI;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.

        builder.Services.AddControllers();
        
        const string connectionString = "Server=hildur.ucn.dk,1433; Database=DMA-CSD-S233_10503086; User Id=DMA-CSD-S233_10503086; Password=Password1!;";
        builder.Services.AddSingleton<IOrderDAO>(provider => new OrderDAO(connectionString));
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        //builder.Services.AddSingleton<ISaleItemStubDAO, SaleItemStub>();
        builder.Services.AddSingleton<ISalesItemsDAO>((_) => new SaleItemsDAO(connectionString));
        builder.Services.AddSingleton<IUserDAO>((_) => new UserDAO(connectionString));
 
        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseAuthorization();


        app.MapControllers();

        app.Run();
    }
}