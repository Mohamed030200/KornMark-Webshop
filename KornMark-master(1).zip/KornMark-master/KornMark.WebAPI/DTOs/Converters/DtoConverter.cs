﻿using KornMark.DAL.DAO;
using System.Collections.Generic;


namespace KornMark.WebAPI.DTOs.Converters;


/// <summary>
/// Tool class for storing extension methods for converting DTOs to Model objects and back
/// </summary>
public static class DtoConverter
{
    #region Saleitem conversion methods
    public static SaleItemDto ToDto(this SaleItem saleitemToConvert)
    {
        var saleitemDto = new SaleItemDto();
        saleitemToConvert.CopyPropertiesTo(saleitemDto);
        return saleitemDto;
    }

    public static SaleItem FromDto(this SaleItemDto saleitemDtoToConvert)
    {
        var saleitem = new SaleItem();
        saleitemDtoToConvert.CopyPropertiesTo(saleitem);
        return saleitem;
    }

    public static IEnumerable<SaleItemDto> ToDtos(this IEnumerable<SaleItem> saleItemToConvert)
    {
        foreach (var saleItem in saleItemToConvert)
        {
            yield return saleItem.ToDto();
        }
    }

    public static IEnumerable<SaleItem> FromDtos(this IEnumerable<SaleItemDto> saleItemDtosToConvert)
    {
        foreach (var saleItemDtos in saleItemDtosToConvert)
        {
            yield return saleItemDtos.FromDto();
        }
    }
    #endregion

    #region User conversion methods
    public static UserDto ToDto(this User userToConvert)
    {
        var userDto = new UserDto();
        userToConvert.CopyPropertiesTo(userDto);
        return userDto;
    }

    public static User FromDto(this UserDto userToConvert)
    {
        var user = new User();
        userToConvert.CopyPropertiesTo(user);
        return user;
    }

    public static IEnumerable<UserDto> ToDtos(this IEnumerable<User> usersToConvert)
    {
        foreach (var user in usersToConvert)
        {
            yield return user.ToDto();
        }
    }
    
    public static IEnumerable<User> FromDtos(this IEnumerable<UserDto> userDtosToConvert)
    {
        foreach(var userDtos in userDtosToConvert)
        {
            yield return userDtos.FromDto();
        }
    }
    #endregion

    #region UserTuple conversion methods
    public static UserTupleDto ToDto(this UserTuple userTupleToConvert)
    {
        var userTupleDto = new UserTupleDto();
        userTupleToConvert.CopyPropertiesTo(userTupleDto);
        return userTupleDto;
    }

    public static UserTuple FromDto(this UserTupleDto userTupleToConvert)
    {
        var userTuple = new UserTuple();
        userTupleToConvert.CopyPropertiesTo(userTuple);
        return userTuple;
    }

    public static IEnumerable<UserTupleDto> ToDtos(this IEnumerable<UserTuple> usersTupleToConvert)
    {
        foreach (var userTuple in usersTupleToConvert)
        {
            yield return userTuple.ToDto();
        }
    }

    public static IEnumerable<UserTuple> FromDtos(this IEnumerable<UserTupleDto> userDtosToConvert)
    {
        foreach (var userTupleDtos in userDtosToConvert)
        {
            yield return userTupleDtos.FromDto();
        }
    }
    #endregion

    #region Orderline conversion methods
    public static OrderLineDto ToDto(this OrderLine orderLineToConvert)
    {
        var orderLineDto = new OrderLineDto();
        orderLineToConvert.CopyPropertiesTo(orderLineDto);
        return orderLineDto;
    }

    public static OrderLine FromDto(this OrderLineDto orderLineToConvert)
    {
        var orderLine = new OrderLine();
        orderLineToConvert.CopyPropertiesTo(orderLine);
        return orderLine;
    }

    public static IEnumerable<OrderLineDto> ToDtos(this IEnumerable<OrderLine> orderLineToConvert)
    {
        foreach (var orderLine in orderLineToConvert)
        {
            yield return orderLine.ToDto();
        }
    }

    public static IEnumerable<OrderLine> FromDtos(this IEnumerable<OrderLineDto> orderLineToConvert)
    {
        foreach (var orderLineDtosVar in orderLineToConvert)
        {
            yield return orderLineDtosVar.FromDto();
        }
    }
    #endregion

    #region Order conversion methods
    public static OrderDto ToDto(this Order orderToConvert)
    {
        if (orderToConvert == null)
            throw new ArgumentNullException(nameof(orderToConvert), "Order cannot be null.");

        var orderDto = new OrderDto
        {
            PhoneFK = orderToConvert.PhoneFK,
            Date = orderToConvert.Date,
            TotalPrice = orderToConvert.TotalPrice,
            OrderLines = orderToConvert.OrderLines.Select(orderlines => new OrderLineDto
            {
                SaleItem = new SaleItemDto
                {
                    Id = orderlines.SaleItem.Id,
                    Name = orderlines.SaleItem.Name,
                    Stock = orderlines.SaleItem.Stock,
                    Price = orderlines.SaleItem.Price
                },
                Amount = orderlines.Amount
            }).ToList()
        };

        return orderDto;
    }


    public static Order FromDto(this OrderDto orderDto)
    {
        if (orderDto == null)
            throw new ArgumentNullException(nameof(orderDto), "Order data cannot be null.");

        var order = new Order
        {
            Date = orderDto.Date,
            TotalPrice = orderDto.TotalPrice,
            PhoneFK = orderDto.PhoneFK,
        };

        if (orderDto.OrderLines != null)
        {
            foreach (var orderLineDto in orderDto.OrderLines)
            {
                if (orderLineDto?.SaleItem == null)
                    throw new ArgumentException("Each order line must have a valid SaleItem.");

                order.OrderLines.Add(new OrderLine
                {
                    SaleItem = new SaleItem
                    {
                        Id = orderLineDto.SaleItem.Id,
                        Name = orderLineDto.SaleItem.Name,
                    },
                    Amount = orderLineDto.Amount
                });
            }
        }

        return order;
    }


    public static IEnumerable<OrderDto> ToDtos(this IEnumerable<Order> orderToConvert)
    {
        foreach (var order in orderToConvert)
        {
            yield return order.ToDto();
        }
    }

    public static IEnumerable<Order> FromDtos(this IEnumerable<OrderDto> orderToConvert)
    {
        foreach (var orderDtosVar in orderToConvert)
        {
            yield return orderDtosVar.FromDto();
        }
    }
    #endregion
}
