﻿namespace KornMark.WebAPI.DTOs
{
    public class UserDto
    {
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
        public string Cvr { get; set; }
        public string Address { get; set; }
        public int AuthorityLevel { get; set; } = 1;
        public int ZipcodeFk { get; set; }
    }
}
