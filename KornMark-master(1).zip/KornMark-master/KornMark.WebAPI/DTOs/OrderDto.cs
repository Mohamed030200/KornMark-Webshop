﻿using KornMark.DAL.DAO;
using KornMark.WebAPI.DTOs;

public class OrderDto
{
    public int OrderNumber { get; set; }
    public DateTime Date { get; set; }
    public decimal TotalPrice { get; set; }

    /// <summary>
    /// Order lines as a collection for serialization.
    /// </summary>
    public List<OrderLineDto> OrderLines { get; set; } = new List<OrderLineDto>();
    public string PhoneFK { get; set; }

}
