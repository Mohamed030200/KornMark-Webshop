﻿namespace KornMark.WebAPI.DTOs;

public class OrderLineDto
{
    /// <summary>
    /// The unique identifier of the associated SaleItem.
    /// </summary>
    public int Amount { get; set; }

    /// <summary>
    /// The name of the associated SaleItem.
    /// </summary>
    /// ændre til saleitem id
    public SaleItemDto SaleItem { get; set; } 
}