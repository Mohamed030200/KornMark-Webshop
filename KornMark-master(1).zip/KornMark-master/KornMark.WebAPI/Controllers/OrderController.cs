﻿using KornMark.DAL.DAO;
using KornMark.WebAPI.DTOs;
using KornMark.WebAPI.DTOs.Converters;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KornMark.WebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class OrderController : ControllerBase
{
    
       private static readonly List<OrderLineDto> OrderLines = new List<OrderLineDto>();
    private readonly IOrderDAO _orderDAO;

    public OrderController(IOrderDAO orderDAO)
    {
        _orderDAO = orderDAO;
    }

    // GET: api/<ValuesController>
    [HttpGet]
    public IEnumerable<OrderLineDto> Get()
    {
        return OrderLines;
    }

    // GET api/<ValuesController>/5
    [HttpGet("{id}")]
    public IActionResult Get(int id)
    {
        var orderLine = OrderLines.FirstOrDefault(ol => ol.SaleItem.Id == id);

        if (orderLine != null)
        {
            return Ok();
        }
        return NotFound();
    }

    // POST api/<ValuesController>
    [HttpPost]
    public IActionResult Post([FromBody] OrderDto orderDto)
    {
        if (orderDto == null)
            return BadRequest("Order data is required.");

        if (orderDto.OrderLines == null || !orderDto.OrderLines.Any())
            return BadRequest("Order lines are required.");

        try
        {
            var orderData = orderDto.FromDto();
            var orderId = _orderDAO.Insert(orderData);
            return CreatedAtAction(nameof(Post), new { id = orderId }, orderId);
        }
        catch (ArgumentNullException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception)
        {
            // Log the actual exception details
            return StatusCode(500, "An error occurred while processing the order.");
        }
    }

    // DELETE api/<ValuesController>/5
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
    }

    [HttpPut("ChangeAmount/{productId}")]
    public IActionResult ChangeAmount(int productId, [FromBody] OrderLineDto orderLineDto)
    {
        if (orderLineDto == null || orderLineDto.SaleItem == null)
        {
            return BadRequest("OrderLine or its SaleItem property cannot be null.");
        }

        // Find the order line with the matching product ID
        var existingOrderLine = OrderLines.FirstOrDefault(ol => ol.SaleItem.Id == productId);

        if (existingOrderLine != null)
        {
            var newAmount = existingOrderLine.Amount + orderLineDto.Amount;

            if (newAmount <= 0)
            {
                // Fjerner orderline hvis der er mindre end 1 saleItem
                OrderLines.Remove(existingOrderLine);
                return Ok("Item removed from order.");
            }
            else
            {
                // Update amount
                existingOrderLine.Amount = newAmount;
                return Ok(existingOrderLine);
            }
        }
        else if (orderLineDto.Amount > 0)
        {
            // Add new item only if the amount is positive
            OrderLines.Add(orderLineDto);
            return Ok(orderLineDto);
        }

        return BadRequest("Invalid amount provided.");
    }
}


