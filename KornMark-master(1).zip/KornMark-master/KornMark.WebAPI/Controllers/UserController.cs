﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using KornMark.DAL.DAO;
using KornMark.WebAPI.DTOs;
using KornMark.WebAPI.DTOs.Converters;

namespace KornMark.WebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class UserController : Controller
{
    private readonly IUserDAO _userDAO;

    public UserController(IUserDAO userDAO)
    {
        _userDAO = userDAO;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserDto>>> Get()
    {
        try
        {
            var users = await _userDAO.GetAll();
            return Ok(users);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
    }

    [HttpGet("{email}")]
    public async Task<ActionResult<UserDto>> GetUser([FromRoute]string email)
    {
        try
        {
            var user = await _userDAO.GetUser(email);
            if(user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
    }

    [HttpPost]
    public async Task<ActionResult<string>> InsertPerson([FromBody]UserDto user)
    {
        try
        {
            var userEmail = await _userDAO.InsertPerson(user.FromDto());
            return CreatedAtAction(nameof(GetUser), new { email = userEmail }, userEmail);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
    }

    [HttpPut("{email}")]
    public async Task<IActionResult> UpdateUser(string email, [FromBody]UserDto user)
    {
        try
        {
            if (email != user.Email)
            {
                return BadRequest(new {error = "Email in route does not match email in body." });
            }

            var success = await _userDAO.Update(user.FromDto());
            if(!success)
            {
                return NotFound(new { error = "User not found." });
            }

            return NoContent();
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
    }

    [HttpDelete("{phone}")]
    public async Task<IActionResult> DeleteUser(string phone)
    {

        try
        {
            var success = await _userDAO.Delete(phone);
            if(!success)
            {
                return NotFound(new { error = "User not found. " });
            }

            return NoContent();
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
    }

    [HttpPost("login")]
    public async Task<ActionResult<string>> Login([FromBody]UserTupleDto userTuple)
    {
        try
        {
            await _userDAO.TryLogin(userTuple.FromDto());
            return Ok(userTuple);
            //var email = await _userDAO.TryLogin(userTuple.);
            //return Ok(email);
            //var userEmail = await _userDAO.TryLogin(userTuple.Email, userTuple.Password);
            //if (userEmail == null)
            //{
            //    return Unauthorized(new { error = "Invalid email or password." });
            //}
            //return Ok(userEmail);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status400BadRequest, new { error = ex.Message });
        }
    }
}
