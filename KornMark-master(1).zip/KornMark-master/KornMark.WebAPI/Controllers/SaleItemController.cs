﻿using KornMark.DAL.DAO;
using Microsoft.AspNetCore.Mvc;
using KornMark.WebAPI.DTOs;
using KornMark.WebAPI.DTOs.Converters;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KornMark.WebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class SaleItemController : ControllerBase
{
    private ISalesItemsDAO _saleItemDAO;

    public SaleItemController(IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");
        _saleItemDAO = new SaleItemsDAO(connectionString);
    }


    // GET: api/<SaleItemController>
    [HttpGet]
    public ActionResult<IEnumerable<SaleItemDto>> Get()
    {
       
        var saleItems = _saleItemDAO.GetSaleItems();

       
        var saleItemDtos = saleItems.ToDtos();

       
        return Ok(saleItemDtos);
    }



    [HttpGet("{id}")]
    public ActionResult<SaleItem> GetById(int id)
    {
        var saleItem = _saleItemDAO.GetSaleItem(id).FirstOrDefault();
        if (saleItem == null)
        {
            return NotFound(new { message = $"SaleItem with ID {id} not found." });
        }

        return Ok(saleItem);
    }

    [HttpPost] 
    public ActionResult<int> Post([FromBody] SaleItemDto saleItemDto)
    {
        var saleItem = saleItemDto.FromDto();
        var saleItemId = _saleItemDAO.Insert(saleItem);
        return CreatedAtAction(nameof(Get), new { Id = saleItemId }, saleItemId);
    }


    [HttpDelete]
    public ActionResult DeleteById(int id)
    {
        var saleItem = _saleItemDAO.GetSaleItem(id).FirstOrDefault();
        if (saleItem == null)
        {
            return NotFound(new { message = $"SaleItem with ID {id} not found." });
        }
        _saleItemDAO.Delete(id);
        return Ok(); // returns 200
    }


}
