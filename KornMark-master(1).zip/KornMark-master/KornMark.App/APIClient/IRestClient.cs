﻿using KornMark.App.ApiClient.DTO;
using User = KornMark.App.ApiClient.DTO;

namespace KornMark.App.ApiClient;

public interface IRestClient
{
    IEnumerable<SaleItemDto> Get100SaleItems();
    //Task<SaleItem> GetSaleItemFromId(int id);
    SaleItemDto GetSaleItemFromId(int id);
    int AddSaleItem(SaleItemDto saleItem);
    Task<bool> DeleteSaleItem(int id);
    decimal GetTotal();
    void Update(int productId, int amount);
    IEnumerable<SaleItemDto> GetSaleItems();
    string AddUser(UserDto user);
    //string TryLogin(string email, string password);
    UserDto TryLogin(string email, string password);
    IEnumerable<UserDto> GetAllUsers();
    Task<bool> DeleteUser(string phone);
}
