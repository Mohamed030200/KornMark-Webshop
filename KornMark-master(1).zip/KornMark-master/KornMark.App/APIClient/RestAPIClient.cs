﻿using Accessibility;
using KornMark.App.ApiClient.DTO;
using RestSharp;
using System.Diagnostics;
using System.Net;

namespace KornMark.App.ApiClient;


public class RestAPIClient : IRestClient
{
    private readonly RestClient _client;

    public RestAPIClient(string baseApiUrl) => _client = new RestClient(baseApiUrl);

    // Opret nyt saleItem
    public int AddSaleItem(SaleItemDto saleItem) 
    {
        var request = new RestRequest("SaleItem", Method.Post);

        // Add the saleItem object as JSON to the body of the request.
        request.AddJsonBody(saleItem);

        // Execute the request and expect an integer response
        var response = _client.Execute<int>(request);

        // Return the data from the response (e.g., the ID of the newly added sale item).
        return response.Data;
    }


    public IEnumerable<SaleItemDto> Get100SaleItems()
    {
        throw new NotImplementedException();
    }

    public SaleItemDto GetSaleItemFromId(int id)
    {
        try
        {
            var request = new RestRequest($"SaleItem/{id}", Method.Get);
            var response = _client.Execute<SaleItemDto>(request);
            return response.Data;
        }

        catch (Exception ex)
        {
            Console.WriteLine($"Error while retrieving SaleItem: {ex.Message}");
            return null;
        }

    }

    public IEnumerable<UserDto> GetAllUsers()
    {
        var request = new RestRequest($"User", Method.Get);
        var response = _client.Execute<List<UserDto>>(request);

        if (response.IsSuccessful && response.Data != null)
        {
            return response.Data;
        }
        else
        {
            throw new Exception($"Error retrieving users: {response.ErrorMessage}");
        }
    }

    public IEnumerable<SaleItemDto> GetSaleItems()
    {
        {
            // Create a RestRequest for the endpoint
            var request = new RestRequest("SaleItem", Method.Get);

            // Execute the request synchronously and get the response
            var response = _client.Execute<List<SaleItemDto>>(request);

            // Check if the response was successful
            if (response.IsSuccessful && response.Data != null)
            {
                // Return only the first 100 items (or fewer if less than 100 are available)
                return response.Data.Take(100);
            }
            else
            {
                // Handle the case when the response is not successful (log, throw exception, etc.)
                throw new Exception($"Error retrieving sale items: {response.ErrorMessage}");
            }
        }
    }

    //used to be string return type
    public UserDto TryLogin(string email, string password)
    {
        try
        {
            var request = new RestRequest("User/login", Method.Post);
            request.AddJsonBody(new Credentials { Email = email, Password = password });
            var response = _client.Execute<UserDto>(request);

            if (response.IsSuccessful && response.Data != null)
            {
                return response.Data;
            }
            throw new Exception($"Login failed: {response.ErrorMessage}");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Exception in TryLogin: {ex.Message}");
            throw;
        }

    }

    public string AddUser(UserDto user)
    {
        var request = new RestRequest("User", Method.Post);
        request.AddJsonBody(user);
        var response = _client.Execute<string>(request);
        if (response == null || !response.IsSuccessful)
        {
            // Log the error
            Console.WriteLine($"Error: {response?.ErrorMessage}");
            return string.Empty; // Return an empty string if the request failed
        }

        return response.Data;
    }

    public async Task<bool> DeleteUser(string phone)
    {
        try
        {
            var request = new RestRequest($"User/{phone}", Method.Delete);

            var response = await _client.ExecuteAsync(request);

            if (response.IsSuccessful)
            {
                return true;
            }
            else
            {
                Console.WriteLine($"Error deleting user with phone {phone}: {response.ErrorMessage}");
                return false;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception deleting user: {ex.Message}");
            return false;
        }
    }

    public async Task<bool> DeleteSaleItem(int id)
    {
        var request = new RestRequest($"SaleItem", Method.Delete);
        request.AddParameter("id", id);
        var response = _client.Execute<int>(request);

        if (response.StatusCode == HttpStatusCode.OK)
        {
            return true; // Assume API returns the number of rows deleted.
        }
        else
        {
            throw new Exception($"Error deleting SaleItem with ID {id}: {response.ErrorMessage}");
        }

    }

    public decimal GetTotal()
    {
        // Assuming the API has an endpoint for retrieving the total price of the current order.
        var request = new RestRequest("Order/Total", Method.Get);
        var response = _client.Execute<decimal>(request);

        if (response.IsSuccessful)
        {
            return response.Data; // Return the total price received from the API.
        }
        else
        {
            throw new Exception($"Error retrieving total: {response.ErrorMessage}");
        }
    }


    public void Update(int productId, int amount)
    {
        try
        {
            var saleItem = new SaleItemDto
            {
                Id = productId,
                Name = "updated Name",
                Category = "updated Category",
                Description = "Updated description"
            };

            var orderLineDto = new OrderLineDto
            {
                Amount = amount,
                SaleItem = saleItem
            };
            var request = new RestRequest($"Order/ChangeAmount/{productId}", Method.Put);
            request.AddJsonBody(orderLineDto); // Send the updated amount in the request body
            var response = _client.Execute(request);
            if (!response.IsSuccessful)
            {
                Debug.WriteLine($"Error: {response.StatusCode} - {response.ErrorMessage}");
                Debug.WriteLine("Response Content: " + response.Content);
                throw new Exception($"Error updating product with ID {productId}: {response.ErrorMessage}");
            }
            Console.WriteLine($"Product with ID {productId} updated successfully.");

        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred while updating product with ID {productId}: {ex.Message}");
            throw;
        }
    }


}