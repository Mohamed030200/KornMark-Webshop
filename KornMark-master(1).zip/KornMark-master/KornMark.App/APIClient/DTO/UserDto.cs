﻿using System.ComponentModel.DataAnnotations;

namespace KornMark.App.ApiClient.DTO;

/// <summary>
/// This class defines the User DTO with validation attributes for the GUI.
/// </summary>
public class UserDto
{
    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
    public string Email { get; set; }

    [Required]
    [DataType(DataType.Password)]
    public string PasswordHash { get; set; }

    [Display(Name = "Phone Number")]
    [Phone(ErrorMessage = "Please enter a valid phone number.")]
    public string Phone { get; set; }

    [Display(Name = "Full Name")]
    [Required(ErrorMessage = "Name is required.")]
    [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters.")]
    public string Name { get; set; }

    [Display(Name = "CVR Number")]
    [StringLength(50, ErrorMessage = "CVR cannot exceed 50 characters.")]
    public string Cvr { get; set; }

    [Display(Name = "Address")]
    [Required(ErrorMessage = "Address is required.")]
    [StringLength(200, ErrorMessage = "Address cannot exceed 200 characters.")]
    public string Address { get; set; }

    [Display(Name = "Authority Level")]
    [Range(1, int.MaxValue, ErrorMessage = "Authority level must be 1 or greater.")]
    public int AuthorityLevel { get; set; } = 1;

    [Display(Name = "Zip Code")]
    [Required(ErrorMessage = "Zip Code is required.")]
    public int ZipcodeFk { get; set; }
}
