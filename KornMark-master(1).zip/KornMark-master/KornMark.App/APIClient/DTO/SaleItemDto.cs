﻿using System.ComponentModel.DataAnnotations;

namespace KornMark.App.ApiClient.DTO;

public class SaleItemDto
{
    public int Id { get; set; }

    [Display(Name = "Produktnavn")]
    [Required(ErrorMessage = "Navn er påkrævet.")]
    [StringLength(100, ErrorMessage = "Max 100 karakterer.")]
    public string Name { get; set; }

    [Display(Name = "Antal på lager")]
    [Range(0, int.MaxValue, ErrorMessage = "Lager kan ikke være negativt.")]
    public int Stock { get; set; }

    [Display(Name = "Pris")]
    [DataType(DataType.Currency)]
    [Range(0.01, double.MaxValue, ErrorMessage = "Prisen må ikke være 0.")]
    public decimal Price { get; set; }

    [Display(Name = "Beskrivelse")]
    [StringLength(500, ErrorMessage = "Beskrivelse må max være 500 karakterer lang.")]
    public string Description { get; set; }

    [Display(Name = "Kategori")]
    public string Category { get; set; }
}
