﻿namespace KornMark.App.ApiClient.DTO;

// This class is for login
public class Credentials
{
    
    public string Email { get; set; }
    public string Password { get; set; }

}
