﻿using System.ComponentModel.DataAnnotations;

namespace KornMark.App.ApiClient.DTO;

public class OrderDto
{
    [Display(Name = "Order Number")]
    public int OrderNumber { get; set; }

    [Display(Name = "Order Date")]
    [DataType(DataType.Date)]
    public DateTime Date { get; set; }

    [Display(Name = "Total Price")]
    [DataType(DataType.Currency)]
    public decimal TotalPrice { get; set; }

    [Display(Name = "Order Lines")]
    public List<OrderLineDto> OrderLines { get; } = new List<OrderLineDto>();
}
