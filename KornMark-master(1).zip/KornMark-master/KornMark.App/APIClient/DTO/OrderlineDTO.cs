﻿using System.ComponentModel.DataAnnotations;

namespace KornMark.App.ApiClient.DTO;

public class OrderLineDto
{
    [Required]
    public SaleItemDto SaleItem { get; set; }

    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Amount must be at least 1.")]
    public int Amount { get; set; }

    [Required]
    [DataType(DataType.Currency)]
    public decimal Price { get; set; }
}

