using KornMark.App.ApiClient;
using KornMark.App.ApiClient.DTO;
using System.Drawing;
using System.Security.AccessControl;

namespace KornMark.App;

public partial class MainForm : Form
{
    private IRestClient _restClient;


    public MainForm(IRestClient restClient)
    {
        _restClient = restClient;
        InitializeComponent();
    }

    // This method runs after the entire layout of WinForms is loaded
    private void MainForm_Load(object sender, EventArgs e)
    {
        AddItemsToSaleItemList();
        AddUsersToUserList();
    }


    private void AddNewUserButton_Click(object sender, EventArgs e)
    {
        CreateNewUser();
    }


    private void SaleItemAddButton_Click(object sender, EventArgs e)
    {
        CreateNewSaleItem();
    }

    private bool IsValidEmail(string email)
    {
        // Simple check for '@' and '.com' in the email
        return email.Contains("@");
    }

    private void CreateNewUser()
    {
        string email = UserEmailTextBox.Text;
        string passwordHash = UserPasswordHashTextBox.Text;
        string phone = UserPhoneTextBox.Text;
        string name = UserNameTextBox.Text;
        string cvr = UserCvrTextBox.Text;
        string address = UserAddressTextBox.Text;
        //int authorityLevel;
        bool isAuthorityLevelValid = int.TryParse(UserAuthorityLevelTextBox.Text, out int authorityLevel);
        //int zipCodeFK;
        int.TryParse(UserZipCodeTextBox.Text, out int zipCodeFK);

        UserDto user = new UserDto()
        {
            Email = email,
            PasswordHash = passwordHash,
            Phone = phone,
            Name = name,
            Cvr = cvr,
            Address = address,
            AuthorityLevel = authorityLevel,
            ZipcodeFk = zipCodeFK
        };

        if(authorityLevel > 3 || authorityLevel < 1)
        {
            MessageBox.Show("Authoritylevel skal v�re mellem 1-3");
            return;
        }
        
        if (!isAuthorityLevelValid)
        {
            MessageBox.Show("Invalid authoritylevel entered. Please enter a valid decimal value.");
            return;  // Optionally, return early or handle the error as needed
        }

        if (!IsValidEmail(email))
        {
            MessageBox.Show("Please enter a valid email address that contains '@'.");
            return;  // Optionally, return early if the email is invalid
        }

        try
        {
            // Call the API to add the user and capture the response
            var response = _restClient.AddUser(user);

            // Check the response code and message

        }
        catch (Exception ex)
        {
            // Catch and handle any errors during the API call or elsewhere
            MessageBox.Show($"Error during user creation: {ex.Message}");
        }
        ClearUserItemTextFields();
        AddUsersToUserList();
    }


    private void CreateNewSaleItem()
    {

        string name = SaleItemNameTextBox.Text;
        int stock;
        int.TryParse(SaleItemStockTextBox.Text, out stock);
        decimal price;
        bool isPriceValid = decimal.TryParse(SaleItemPriceTextBox.Text, out price);
        bool isStockValid = int.TryParse(SaleItemStockTextBox.Text, out stock);
        string description = SaleItemDescriptionTextBox.Text;
        string category = SaleItemCategoryTextBox.Text;

        SaleItemDto saleItem = new SaleItemDto()
        {
            Name = name,
            Stock = stock,
            Price = price,
            Description = description,
            Category = category
        };

        if (!isPriceValid || !isStockValid)
        {
            MessageBox.Show("Prisen og lager skal v�re et tal.");
            return;  // Optionally, return early or handle the error as needed
        }
        _restClient.AddSaleItem(saleItem);
        ClearCreateSaleItemTextFields(); // sletter teksten der st�r i boxene
        AddItemsToSaleItemList(); // Opdaterer bare listen af items s� det nye saleItem kommer med p� listen
    }

    private void ClearUserItemTextFields()
    {
        UserEmailTextBox.Text = string.Empty;
        UserPasswordHashTextBox.Text = string.Empty;
        UserPhoneTextBox.Text = string.Empty;
        UserNameTextBox.Text = string.Empty;
        UserCvrTextBox.Text = string.Empty;
        UserAddressTextBox.Text = string.Empty;
        UserAuthorityLevelTextBox.Text = string.Empty;
        UserZipCodeTextBox.Text = string.Empty;
    }

    private void ClearCreateSaleItemTextFields()
    {
        SaleItemNameTextBox.Text = string.Empty;
        SaleItemStockTextBox.Text = string.Empty;
        SaleItemPriceTextBox.Text = string.Empty;
        SaleItemDescriptionTextBox.Text = string.Empty;
        SaleItemCategoryTextBox.Text = string.Empty;
    }

    private void AddUsersToUserList()
    {
        UserList.Items.Clear();

        var users = _restClient.GetAllUsers();

        foreach (var user in users)
        {
            ListViewItem listViewItem = new ListViewItem(user.Email);

            listViewItem.SubItems.Add(user.PasswordHash.ToString());
            listViewItem.SubItems.Add(user.Phone.ToString());
            listViewItem.SubItems.Add(user.Name.ToString());
            listViewItem.SubItems.Add(user.Cvr.ToString());
            listViewItem.SubItems.Add(user.Address.ToString());
            listViewItem.SubItems.Add(user.AuthorityLevel.ToString());
            listViewItem.SubItems.Add(user.ZipcodeFk.ToString());

            UserList.Items.Add(listViewItem);
        }
        AutoResizeUserColumns();
    }


    private void AddItemsToSaleItemList()
    {
        SaleItemList.Items.Clear();

        var saleItems = _restClient.GetSaleItems();

        foreach (var saleItem in saleItems)
        {
            ListViewItem listViewItem = new ListViewItem(saleItem.Id.ToString());
            listViewItem.SubItems.Add(saleItem.Name);
            listViewItem.SubItems.Add(saleItem.Stock.ToString());
            listViewItem.SubItems.Add(saleItem.Price.ToString());
            listViewItem.SubItems.Add(saleItem.Description.ToString());
            listViewItem.SubItems.Add(saleItem.Category.ToString());

            SaleItemList.Items.Add(listViewItem);

        }
        AutoResizeSaleItemColumns();
    }
    private void AutoResizeUserColumns()
    {
        UserList.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize); // Email
        UserList.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize); // Phone
        UserList.AutoResizeColumn(3, ColumnHeaderAutoResizeStyle.HeaderSize);
        UserList.AutoResizeColumn(4, ColumnHeaderAutoResizeStyle.HeaderSize);
        UserList.AutoResizeColumn(5, ColumnHeaderAutoResizeStyle.HeaderSize);
        UserList.AutoResizeColumn(6, ColumnHeaderAutoResizeStyle.HeaderSize);
        UserList.AutoResizeColumn(7, ColumnHeaderAutoResizeStyle.HeaderSize);
    }

    private void AutoResizeSaleItemColumns()
    {
        //Den her kode auto scaler column
        SaleItemList.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize); //Index 0 == Id column
        SaleItemList.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize); //Index 1 == name column
        SaleItemList.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize); //Index 2 == stock column
        SaleItemList.AutoResizeColumn(3, ColumnHeaderAutoResizeStyle.HeaderSize); //Index 3 == price column
        SaleItemList.AutoResizeColumn(5, ColumnHeaderAutoResizeStyle.HeaderSize); //Index 5 == category column
    }

    private void buttonGetProducts_Click(object sender, EventArgs e)
    {
        AddItemsToSaleItemList();
    }

    private void buttonGetUsers_Click(object sender, EventArgs e)
    {
        AddUsersToUserList();
    }

    private void SaleItemDeleteButton_Click(object sender, EventArgs e)
    {
        ConfirmDeleteSaleItem();
    }
    private void buttonDeleteUser_Click(object sender, EventArgs e)
    {
        ConfirmDeleteUser();
    }


    private void ConfirmDeleteSaleItem()
    {
        // Show a confirmation dialog
        var result = MessageBox.Show(
            "Er du sikker p� at du vil slette det valgte element?",
            "Bekr�ft sletning",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        );

        if (result == DialogResult.Yes)
        {
            DeleteSaleItem();
        }

    }
    private void ConfirmDeleteUser()
    {
        var result = MessageBox.Show(
            "Are you sure you want to delete this User?",
            "Confirm Deletion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        );
        if (result == DialogResult.Yes)
        {
            DeleteUser();
        }
    }

    private void DeleteUser()
    {
        if (UserList.SelectedItems.Count > 0)
        {
            string phone = UserList.SelectedItems[0].SubItems[2].Text;

            try
            {
                _restClient.DeleteUser(phone);
                Thread.Sleep(1000);
                AddUsersToUserList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting User: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            MessageBox.Show("Please select a User to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void DeleteSaleItem()
    {
        if (SaleItemList.SelectedItems.Count > 0) // Ensures a saleItem is selected
        {
            int saleItemId = int.Parse(SaleItemList.SelectedItems[0].SubItems[0].Text); // 0 because ID is the first row

            try
            {
                _restClient.DeleteSaleItem(saleItemId);
                AddItemsToSaleItemList(); // Refresh the list
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting SaleItem: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            MessageBox.Show("Please select a SaleItem to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

}
