using Microsoft.Extensions.DependencyInjection; // Import the DI namespace
using KornMark.App.ApiClient;
using System;

namespace KornMark.App;

internal static class Program
{
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main()
    {
        // Set up dependency injection container
        var services = new ServiceCollection();

        // Register your services here
        services.AddSingleton<IRestClient>((_) => new RestAPIClient("https://localhost:7165/api"));

        // Register MainForm as a service
        services.AddSingleton<MainForm>();

        // Build the service provider
        var serviceProvider = services.BuildServiceProvider();

        // Initialize the application
        ApplicationConfiguration.Initialize();

        // Run the application with MainForm resolved by DI
        var mainForm = serviceProvider.GetRequiredService<MainForm>();
        Application.Run(mainForm);
    }
}
