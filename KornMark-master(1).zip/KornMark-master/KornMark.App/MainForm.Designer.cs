﻿namespace KornMark.App
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListViewItem listViewItem1 = new ListViewItem("");
            KornMarkPanel = new Panel();
            KornMarkTabControl = new TabControl();
            SaleItemTab = new TabPage();
            buttonGetProducts = new Button();
            SaleItemCategoryLabel = new Label();
            SaleItemDescriptionLabel = new Label();
            SaleItemCategoryTextBox = new TextBox();
            SaleItemDescriptionTextBox = new TextBox();
            SaleItemPriceTextBox = new TextBox();
            SaleItemPriceLabel = new Label();
            SaleItemStockLabel = new Label();
            SaleItemNameLabel = new Label();
            SaleItemStockTextBox = new TextBox();
            SaleItemNameTextBox = new TextBox();
            SaleItemList = new ListView();
            IdColumn = new ColumnHeader();
            NameColumn = new ColumnHeader();
            StockColumn = new ColumnHeader();
            PriceColumn = new ColumnHeader();
            DescriptionColumn = new ColumnHeader();
            CategoryColumn = new ColumnHeader();
            SaleItemEditButton = new Button();
            SaleItemDeleteButton = new Button();
            SaleItemAddButton = new Button();
            UserPage = new TabPage();
            AddNewUserButton = new Button();
            UserZipCodeTextBox = new TextBox();
            UserAuthorityLevelTextBox = new TextBox();
            UserAddressTextBox = new TextBox();
            UserCvrTextBox = new TextBox();
            UserNameTextBox = new TextBox();
            UserPhoneTextBox = new TextBox();
            UserPasswordHashTextBox = new TextBox();
            UserEmailTextBox = new TextBox();
            UserZipCodeLabel = new Label();
            UserAuthorityLevelLabel = new Label();
            UserAddressLabel = new Label();
            UserCvrLabel = new Label();
            UserNameLabel = new Label();
            UserPhoneLabel = new Label();
            UserPasswordHashLabel = new Label();
            UserEmailLabel = new Label();
            buttonGetUsers = new Button();
            buttonEditUsers = new Button();
            buttonDeleteUser = new Button();
            UserList = new ListView();
            UserEmailColumn = new ColumnHeader();
            UserPasswordHashColumn = new ColumnHeader();
            UserPhoneColumn = new ColumnHeader();
            UserNameColumn = new ColumnHeader();
            UserCvrColumn = new ColumnHeader();
            UserAddressColumn = new ColumnHeader();
            UserAuthorityLevelColumn = new ColumnHeader();
            UserZipCodeColumn = new ColumnHeader();
            OrderTab = new TabPage();
            KornMarkPanel.SuspendLayout();
            KornMarkTabControl.SuspendLayout();
            SaleItemTab.SuspendLayout();
            UserPage.SuspendLayout();
            SuspendLayout();
            // 
            // KornMarkPanel
            // 
            KornMarkPanel.Controls.Add(KornMarkTabControl);
            KornMarkPanel.Dock = DockStyle.Fill;
            KornMarkPanel.Location = new Point(0, 0);
            KornMarkPanel.Margin = new Padding(3, 4, 3, 4);
            KornMarkPanel.Name = "KornMarkPanel";
            KornMarkPanel.Size = new Size(1099, 795);
            KornMarkPanel.TabIndex = 0;
            // 
            // KornMarkTabControl
            // 
            KornMarkTabControl.Controls.Add(SaleItemTab);
            KornMarkTabControl.Controls.Add(UserPage);
            KornMarkTabControl.Controls.Add(OrderTab);
            KornMarkTabControl.Location = new Point(3, 4);
            KornMarkTabControl.Margin = new Padding(3, 4, 3, 4);
            KornMarkTabControl.Name = "KornMarkTabControl";
            KornMarkTabControl.SelectedIndex = 0;
            KornMarkTabControl.Size = new Size(1096, 791);
            KornMarkTabControl.TabIndex = 1;
            // 
            // SaleItemTab
            // 
            SaleItemTab.Controls.Add(buttonGetProducts);
            SaleItemTab.Controls.Add(SaleItemCategoryLabel);
            SaleItemTab.Controls.Add(SaleItemDescriptionLabel);
            SaleItemTab.Controls.Add(SaleItemCategoryTextBox);
            SaleItemTab.Controls.Add(SaleItemDescriptionTextBox);
            SaleItemTab.Controls.Add(SaleItemPriceTextBox);
            SaleItemTab.Controls.Add(SaleItemPriceLabel);
            SaleItemTab.Controls.Add(SaleItemStockLabel);
            SaleItemTab.Controls.Add(SaleItemNameLabel);
            SaleItemTab.Controls.Add(SaleItemStockTextBox);
            SaleItemTab.Controls.Add(SaleItemNameTextBox);
            SaleItemTab.Controls.Add(SaleItemList);
            SaleItemTab.Controls.Add(SaleItemEditButton);
            SaleItemTab.Controls.Add(SaleItemDeleteButton);
            SaleItemTab.Controls.Add(SaleItemAddButton);
            SaleItemTab.Location = new Point(4, 29);
            SaleItemTab.Margin = new Padding(3, 4, 3, 4);
            SaleItemTab.Name = "SaleItemTab";
            SaleItemTab.Padding = new Padding(3, 4, 3, 4);
            SaleItemTab.Size = new Size(1088, 758);
            SaleItemTab.TabIndex = 0;
            SaleItemTab.Text = "SaleItems";
            SaleItemTab.UseVisualStyleBackColor = true;
            // 
            // buttonGetProducts
            // 
            buttonGetProducts.Location = new Point(190, 8);
            buttonGetProducts.Margin = new Padding(3, 4, 3, 4);
            buttonGetProducts.Name = "buttonGetProducts";
            buttonGetProducts.Size = new Size(125, 31);
            buttonGetProducts.TabIndex = 19;
            buttonGetProducts.Text = "Hent produkter";
            buttonGetProducts.UseVisualStyleBackColor = true;
            buttonGetProducts.Click += buttonGetProducts_Click;
            // 
            // SaleItemCategoryLabel
            // 
            SaleItemCategoryLabel.AutoSize = true;
            SaleItemCategoryLabel.Location = new Point(768, 255);
            SaleItemCategoryLabel.Name = "SaleItemCategoryLabel";
            SaleItemCategoryLabel.Size = new Size(66, 20);
            SaleItemCategoryLabel.TabIndex = 18;
            SaleItemCategoryLabel.Text = "Kategori";
            // 
            // SaleItemDescriptionLabel
            // 
            SaleItemDescriptionLabel.AutoSize = true;
            SaleItemDescriptionLabel.Location = new Point(768, 185);
            SaleItemDescriptionLabel.Name = "SaleItemDescriptionLabel";
            SaleItemDescriptionLabel.Size = new Size(81, 20);
            SaleItemDescriptionLabel.TabIndex = 17;
            SaleItemDescriptionLabel.Text = "Beskrivelse";
            // 
            // SaleItemCategoryTextBox
            // 
            SaleItemCategoryTextBox.Location = new Point(768, 279);
            SaleItemCategoryTextBox.Margin = new Padding(3, 4, 3, 4);
            SaleItemCategoryTextBox.Name = "SaleItemCategoryTextBox";
            SaleItemCategoryTextBox.Size = new Size(124, 27);
            SaleItemCategoryTextBox.TabIndex = 16;
            // 
            // SaleItemDescriptionTextBox
            // 
            SaleItemDescriptionTextBox.Location = new Point(768, 209);
            SaleItemDescriptionTextBox.Margin = new Padding(3, 4, 3, 4);
            SaleItemDescriptionTextBox.Name = "SaleItemDescriptionTextBox";
            SaleItemDescriptionTextBox.Size = new Size(124, 27);
            SaleItemDescriptionTextBox.TabIndex = 15;
            // 
            // SaleItemPriceTextBox
            // 
            SaleItemPriceTextBox.Location = new Point(837, 132);
            SaleItemPriceTextBox.Margin = new Padding(3, 4, 3, 4);
            SaleItemPriceTextBox.Name = "SaleItemPriceTextBox";
            SaleItemPriceTextBox.Size = new Size(55, 27);
            SaleItemPriceTextBox.TabIndex = 14;
            // 
            // SaleItemPriceLabel
            // 
            SaleItemPriceLabel.AutoSize = true;
            SaleItemPriceLabel.Location = new Point(839, 108);
            SaleItemPriceLabel.Name = "SaleItemPriceLabel";
            SaleItemPriceLabel.Size = new Size(32, 20);
            SaleItemPriceLabel.TabIndex = 13;
            SaleItemPriceLabel.Text = "Pris";
            // 
            // SaleItemStockLabel
            // 
            SaleItemStockLabel.AutoSize = true;
            SaleItemStockLabel.Location = new Point(768, 108);
            SaleItemStockLabel.Name = "SaleItemStockLabel";
            SaleItemStockLabel.Size = new Size(46, 20);
            SaleItemStockLabel.TabIndex = 12;
            SaleItemStockLabel.Text = "Lager";
            // 
            // SaleItemNameLabel
            // 
            SaleItemNameLabel.AutoSize = true;
            SaleItemNameLabel.Location = new Point(768, 44);
            SaleItemNameLabel.Name = "SaleItemNameLabel";
            SaleItemNameLabel.Size = new Size(43, 20);
            SaleItemNameLabel.TabIndex = 11;
            SaleItemNameLabel.Text = "Navn";
            // 
            // SaleItemStockTextBox
            // 
            SaleItemStockTextBox.Location = new Point(768, 132);
            SaleItemStockTextBox.Margin = new Padding(3, 4, 3, 4);
            SaleItemStockTextBox.Name = "SaleItemStockTextBox";
            SaleItemStockTextBox.Size = new Size(61, 27);
            SaleItemStockTextBox.TabIndex = 10;
            // 
            // SaleItemNameTextBox
            // 
            SaleItemNameTextBox.Location = new Point(768, 68);
            SaleItemNameTextBox.Margin = new Padding(3, 4, 3, 4);
            SaleItemNameTextBox.Name = "SaleItemNameTextBox";
            SaleItemNameTextBox.Size = new Size(124, 27);
            SaleItemNameTextBox.TabIndex = 9;
            // 
            // SaleItemList
            // 
            SaleItemList.Columns.AddRange(new ColumnHeader[] { IdColumn, NameColumn, StockColumn, PriceColumn, DescriptionColumn, CategoryColumn });
            SaleItemList.FullRowSelect = true;
            SaleItemList.GridLines = true;
            SaleItemList.Items.AddRange(new ListViewItem[] { listViewItem1 });
            SaleItemList.Location = new Point(7, 47);
            SaleItemList.Margin = new Padding(3, 4, 3, 4);
            SaleItemList.Name = "SaleItemList";
            SaleItemList.Size = new Size(469, 477);
            SaleItemList.TabIndex = 8;
            SaleItemList.UseCompatibleStateImageBehavior = false;
            SaleItemList.View = View.Details;
            // 
            // IdColumn
            // 
            IdColumn.Text = "Id";
            // 
            // NameColumn
            // 
            NameColumn.Tag = "";
            NameColumn.Text = "Navn";
            // 
            // StockColumn
            // 
            StockColumn.Text = "Stock";
            // 
            // PriceColumn
            // 
            PriceColumn.Text = "Pris";
            // 
            // DescriptionColumn
            // 
            DescriptionColumn.Text = "Description";
            DescriptionColumn.Width = 160;
            // 
            // CategoryColumn
            // 
            CategoryColumn.Text = "Kategori";
            // 
            // SaleItemEditButton
            // 
            SaleItemEditButton.Location = new Point(6, 8);
            SaleItemEditButton.Margin = new Padding(3, 4, 3, 4);
            SaleItemEditButton.Name = "SaleItemEditButton";
            SaleItemEditButton.Size = new Size(86, 31);
            SaleItemEditButton.TabIndex = 7;
            SaleItemEditButton.Text = "Rediger";
            SaleItemEditButton.UseVisualStyleBackColor = true;
            // 
            // SaleItemDeleteButton
            // 
            SaleItemDeleteButton.Location = new Point(98, 8);
            SaleItemDeleteButton.Margin = new Padding(3, 4, 3, 4);
            SaleItemDeleteButton.Name = "SaleItemDeleteButton";
            SaleItemDeleteButton.Size = new Size(86, 31);
            SaleItemDeleteButton.TabIndex = 6;
            SaleItemDeleteButton.Text = "Slet";
            SaleItemDeleteButton.UseVisualStyleBackColor = true;
            SaleItemDeleteButton.Click += SaleItemDeleteButton_Click;
            // 
            // SaleItemAddButton
            // 
            SaleItemAddButton.Location = new Point(768, 317);
            SaleItemAddButton.Margin = new Padding(3, 4, 3, 4);
            SaleItemAddButton.Name = "SaleItemAddButton";
            SaleItemAddButton.Size = new Size(125, 31);
            SaleItemAddButton.TabIndex = 0;
            SaleItemAddButton.Text = "Tilføj nyt produkt";
            SaleItemAddButton.UseVisualStyleBackColor = true;
            SaleItemAddButton.Click += SaleItemAddButton_Click;
            // 
            // UserPage
            // 
            UserPage.Controls.Add(AddNewUserButton);
            UserPage.Controls.Add(UserZipCodeTextBox);
            UserPage.Controls.Add(UserAuthorityLevelTextBox);
            UserPage.Controls.Add(UserAddressTextBox);
            UserPage.Controls.Add(UserCvrTextBox);
            UserPage.Controls.Add(UserNameTextBox);
            UserPage.Controls.Add(UserPhoneTextBox);
            UserPage.Controls.Add(UserPasswordHashTextBox);
            UserPage.Controls.Add(UserEmailTextBox);
            UserPage.Controls.Add(UserZipCodeLabel);
            UserPage.Controls.Add(UserAuthorityLevelLabel);
            UserPage.Controls.Add(UserAddressLabel);
            UserPage.Controls.Add(UserCvrLabel);
            UserPage.Controls.Add(UserNameLabel);
            UserPage.Controls.Add(UserPhoneLabel);
            UserPage.Controls.Add(UserPasswordHashLabel);
            UserPage.Controls.Add(UserEmailLabel);
            UserPage.Controls.Add(buttonGetUsers);
            UserPage.Controls.Add(buttonEditUsers);
            UserPage.Controls.Add(buttonDeleteUser);
            UserPage.Controls.Add(UserList);
            UserPage.Location = new Point(4, 29);
            UserPage.Margin = new Padding(3, 4, 3, 4);
            UserPage.Name = "UserPage";
            UserPage.Padding = new Padding(3, 4, 3, 4);
            UserPage.Size = new Size(1088, 758);
            UserPage.TabIndex = 1;
            UserPage.Text = "Users";
            UserPage.UseVisualStyleBackColor = true;
            // 
            // AddNewUserButton
            // 
            AddNewUserButton.Location = new Point(839, 520);
            AddNewUserButton.Margin = new Padding(3, 4, 3, 4);
            AddNewUserButton.Name = "AddNewUserButton";
            AddNewUserButton.Size = new Size(114, 31);
            AddNewUserButton.TabIndex = 24;
            AddNewUserButton.Text = "Opret ny bruger";
            AddNewUserButton.UseVisualStyleBackColor = true;
            AddNewUserButton.Click += AddNewUserButton_Click;
            // 
            // UserZipCodeTextBox
            // 
            UserZipCodeTextBox.Location = new Point(839, 481);
            UserZipCodeTextBox.Margin = new Padding(3, 4, 3, 4);
            UserZipCodeTextBox.Name = "UserZipCodeTextBox";
            UserZipCodeTextBox.Size = new Size(238, 27);
            UserZipCodeTextBox.TabIndex = 19;
            // 
            // UserAuthorityLevelTextBox
            // 
            UserAuthorityLevelTextBox.Location = new Point(839, 423);
            UserAuthorityLevelTextBox.Margin = new Padding(3, 4, 3, 4);
            UserAuthorityLevelTextBox.Name = "UserAuthorityLevelTextBox";
            UserAuthorityLevelTextBox.Size = new Size(238, 27);
            UserAuthorityLevelTextBox.TabIndex = 18;
            // 
            // UserAddressTextBox
            // 
            UserAddressTextBox.Location = new Point(839, 364);
            UserAddressTextBox.Margin = new Padding(3, 4, 3, 4);
            UserAddressTextBox.Name = "UserAddressTextBox";
            UserAddressTextBox.Size = new Size(238, 27);
            UserAddressTextBox.TabIndex = 17;
            // 
            // UserCvrTextBox
            // 
            UserCvrTextBox.Location = new Point(839, 305);
            UserCvrTextBox.Margin = new Padding(3, 4, 3, 4);
            UserCvrTextBox.Name = "UserCvrTextBox";
            UserCvrTextBox.Size = new Size(238, 27);
            UserCvrTextBox.TabIndex = 16;
            // 
            // UserNameTextBox
            // 
            UserNameTextBox.Location = new Point(839, 247);
            UserNameTextBox.Margin = new Padding(3, 4, 3, 4);
            UserNameTextBox.Name = "UserNameTextBox";
            UserNameTextBox.Size = new Size(238, 27);
            UserNameTextBox.TabIndex = 15;
            // 
            // UserPhoneTextBox
            // 
            UserPhoneTextBox.Location = new Point(839, 188);
            UserPhoneTextBox.Margin = new Padding(3, 4, 3, 4);
            UserPhoneTextBox.Name = "UserPhoneTextBox";
            UserPhoneTextBox.Size = new Size(238, 27);
            UserPhoneTextBox.TabIndex = 14;
            // 
            // UserPasswordHashTextBox
            // 
            UserPasswordHashTextBox.Location = new Point(839, 129);
            UserPasswordHashTextBox.Margin = new Padding(3, 4, 3, 4);
            UserPasswordHashTextBox.Name = "UserPasswordHashTextBox";
            UserPasswordHashTextBox.Size = new Size(238, 27);
            UserPasswordHashTextBox.TabIndex = 13;
            // 
            // UserEmailTextBox
            // 
            UserEmailTextBox.Location = new Point(839, 71);
            UserEmailTextBox.Margin = new Padding(3, 4, 3, 4);
            UserEmailTextBox.Name = "UserEmailTextBox";
            UserEmailTextBox.Size = new Size(238, 27);
            UserEmailTextBox.TabIndex = 12;
            // 
            // UserZipCodeLabel
            // 
            UserZipCodeLabel.AutoSize = true;
            UserZipCodeLabel.Location = new Point(839, 457);
            UserZipCodeLabel.Name = "UserZipCodeLabel";
            UserZipCodeLabel.Size = new Size(66, 20);
            UserZipCodeLabel.TabIndex = 11;
            UserZipCodeLabel.Text = "ZipCode";
            // 
            // UserAuthorityLevelLabel
            // 
            UserAuthorityLevelLabel.AutoSize = true;
            UserAuthorityLevelLabel.Location = new Point(839, 399);
            UserAuthorityLevelLabel.Name = "UserAuthorityLevelLabel";
            UserAuthorityLevelLabel.Size = new Size(104, 20);
            UserAuthorityLevelLabel.TabIndex = 10;
            UserAuthorityLevelLabel.Text = "AuthorityLevel";
            // 
            // UserAddressLabel
            // 
            UserAddressLabel.AutoSize = true;
            UserAddressLabel.Location = new Point(839, 340);
            UserAddressLabel.Name = "UserAddressLabel";
            UserAddressLabel.Size = new Size(70, 20);
            UserAddressLabel.TabIndex = 9;
            UserAddressLabel.Text = "Addresse";
            // 
            // UserCvrLabel
            // 
            UserCvrLabel.AutoSize = true;
            UserCvrLabel.Location = new Point(839, 281);
            UserCvrLabel.Name = "UserCvrLabel";
            UserCvrLabel.Size = new Size(30, 20);
            UserCvrLabel.TabIndex = 8;
            UserCvrLabel.Text = "Cvr";
            // 
            // UserNameLabel
            // 
            UserNameLabel.AutoSize = true;
            UserNameLabel.Location = new Point(837, 223);
            UserNameLabel.Name = "UserNameLabel";
            UserNameLabel.Size = new Size(43, 20);
            UserNameLabel.TabIndex = 7;
            UserNameLabel.Text = "Navn";
            // 
            // UserPhoneLabel
            // 
            UserPhoneLabel.AutoSize = true;
            UserPhoneLabel.Location = new Point(839, 164);
            UserPhoneLabel.Name = "UserPhoneLabel";
            UserPhoneLabel.Size = new Size(58, 20);
            UserPhoneLabel.TabIndex = 6;
            UserPhoneLabel.Text = "Telefon";
            // 
            // UserPasswordHashLabel
            // 
            UserPasswordHashLabel.AutoSize = true;
            UserPasswordHashLabel.Location = new Point(839, 105);
            UserPasswordHashLabel.Name = "UserPasswordHashLabel";
            UserPasswordHashLabel.Size = new Size(70, 20);
            UserPasswordHashLabel.TabIndex = 5;
            UserPasswordHashLabel.Text = "Password";
            // 
            // UserEmailLabel
            // 
            UserEmailLabel.AutoSize = true;
            UserEmailLabel.Location = new Point(839, 47);
            UserEmailLabel.Name = "UserEmailLabel";
            UserEmailLabel.Size = new Size(46, 20);
            UserEmailLabel.TabIndex = 4;
            UserEmailLabel.Text = "Email";
            // 
            // buttonGetUsers
            // 
            buttonGetUsers.Location = new Point(192, 8);
            buttonGetUsers.Margin = new Padding(3, 4, 3, 4);
            buttonGetUsers.Name = "buttonGetUsers";
            buttonGetUsers.Size = new Size(95, 31);
            buttonGetUsers.TabIndex = 3;
            buttonGetUsers.Text = "Hent Users";
            buttonGetUsers.UseVisualStyleBackColor = true;
            buttonGetUsers.Click += buttonGetUsers_Click;
            // 
            // buttonEditUsers
            // 
            buttonEditUsers.Location = new Point(99, 8);
            buttonEditUsers.Margin = new Padding(3, 4, 3, 4);
            buttonEditUsers.Name = "buttonEditUsers";
            buttonEditUsers.Size = new Size(86, 31);
            buttonEditUsers.TabIndex = 2;
            buttonEditUsers.Text = "Rediger";
            buttonEditUsers.UseVisualStyleBackColor = true;
            // 
            // buttonDeleteUser
            // 
            buttonDeleteUser.Location = new Point(7, 8);
            buttonDeleteUser.Margin = new Padding(3, 4, 3, 4);
            buttonDeleteUser.Name = "buttonDeleteUser";
            buttonDeleteUser.Size = new Size(86, 31);
            buttonDeleteUser.TabIndex = 1;
            buttonDeleteUser.Text = "Slet";
            buttonDeleteUser.UseVisualStyleBackColor = true;
            buttonDeleteUser.Click += buttonDeleteUser_Click;
            // 
            // UserList
            // 
            UserList.Columns.AddRange(new ColumnHeader[] { UserEmailColumn, UserPasswordHashColumn, UserPhoneColumn, UserNameColumn, UserCvrColumn, UserAddressColumn, UserAuthorityLevelColumn, UserZipCodeColumn });
            UserList.FullRowSelect = true;
            UserList.GridLines = true;
            UserList.Location = new Point(7, 47);
            UserList.Margin = new Padding(3, 4, 3, 4);
            UserList.Name = "UserList";
            UserList.Size = new Size(802, 701);
            UserList.TabIndex = 0;
            UserList.UseCompatibleStateImageBehavior = false;
            UserList.View = View.Details;
            // 
            // UserEmailColumn
            // 
            UserEmailColumn.Text = "Email";
            // 
            // UserPasswordHashColumn
            // 
            UserPasswordHashColumn.Text = "PasswordHash";
            // 
            // UserPhoneColumn
            // 
            UserPhoneColumn.Text = "Telefon";
            // 
            // UserNameColumn
            // 
            UserNameColumn.Text = "Navn";
            // 
            // UserCvrColumn
            // 
            UserCvrColumn.Text = "Cvr";
            // 
            // UserAddressColumn
            // 
            UserAddressColumn.Text = "Addresse";
            // 
            // UserAuthorityLevelColumn
            // 
            UserAuthorityLevelColumn.Text = "AuthorityLevel";
            // 
            // UserZipCodeColumn
            // 
            UserZipCodeColumn.Text = "Postnummer";
            // 
            // OrderTab
            // 
            OrderTab.Location = new Point(4, 29);
            OrderTab.Margin = new Padding(3, 4, 3, 4);
            OrderTab.Name = "OrderTab";
            OrderTab.Padding = new Padding(3, 4, 3, 4);
            OrderTab.Size = new Size(1088, 758);
            OrderTab.TabIndex = 2;
            OrderTab.Text = "Orders";
            OrderTab.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1099, 795);
            Controls.Add(KornMarkPanel);
            Margin = new Padding(3, 4, 3, 4);
            Name = "MainForm";
            Text = "KornMark";
            KornMarkPanel.ResumeLayout(false);
            KornMarkTabControl.ResumeLayout(false);
            SaleItemTab.ResumeLayout(false);
            SaleItemTab.PerformLayout();
            UserPage.ResumeLayout(false);
            UserPage.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel KornMarkPanel;
        private TabControl KornMarkTabControl;
        private TabPage SaleItemTab;
        private TabPage UserPage;
        private Button SaleItemAddButton;
        private TabPage OrderTab;
        private Button SaleItemEditButton;
        private Button SaleItemDeleteButton;
        private ListView SaleItemList;
        private ColumnHeader NameColumn;
        private ColumnHeader StockColumn;
        private ColumnHeader PriceColumn;
        private ColumnHeader DescriptionColumn;
        private ColumnHeader CategoryColumn;
        private Label SaleItemNameLabel;
        private TextBox SaleItemStockTextBox;
        private TextBox SaleItemNameTextBox;
        private Label SaleItemStockLabel;
        private Label SaleItemPriceLabel;
        private Label SaleItemCategoryLabel;
        private Label SaleItemDescriptionLabel;
        private TextBox SaleItemCategoryTextBox;
        private TextBox SaleItemDescriptionTextBox;
        private TextBox SaleItemPriceTextBox;
        private Button buttonGetProducts;
        private ListView UserList;
        private ColumnHeader UserEmailColumn;
        private ColumnHeader UserPasswordHashColumn;
        private ColumnHeader UserPhoneColumn;
        private ColumnHeader UserNameColumn;
        private ColumnHeader UserCvrColumn;
        private ColumnHeader UserAddressColumn;
        private ColumnHeader UserAuthorityLevelColumn;
        private ColumnHeader UserZipCodeColumn;
        private Button buttonGetUsers;
        private Button buttonEditUsers;
        private Button buttonDeleteUser;
        private TextBox UserPasswordHashTextBox;
        private TextBox UserEmailTextBox;
        private Label UserZipCodeLabel;
        private Label UserAuthorityLevelLabel;
        private Label UserAddressLabel;
        private Label UserCvrLabel;
        private Label UserNameLabel;
        private Label UserPhoneLabel;
        private Label UserPasswordHashLabel;
        private Label UserEmailLabel;
        private TextBox UserZipCodeTextBox;
        private TextBox UserAuthorityLevelTextBox;
        private TextBox UserAddressTextBox;
        private TextBox UserCvrTextBox;
        private TextBox UserNameTextBox;
        private TextBox UserPhoneTextBox;
        private Button AddNewUserButton;
        private ColumnHeader IdColumn;
    }
}
