using KornMark.DAL.DAO;
using KornMark.WebAPI.Controllers;
using KornMark.WebAPI.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace KornMark.NUnitTest;

public class OrderControllerTest
{
    private OrderController _orderController;
    private readonly IOrderDAO _orderDAO;

    [SetUp]
    public void Setup()
    {
        _orderController = new OrderController(_orderDAO);
    }

    [Test]
    public void ReturnsEmptyOrderLinesWhenNoData()
    {
        // Arrange (controller initialized with empty OrderLines)

        // Act
        var result = _orderController.Get();

        // Assert
        Assert.IsNotNull(result);
        Assert.IsEmpty(result);
    }

    [Test]
    public void ReturnsBadRequestWhenOrderDtoIsNull()
    {
        // Arrange
        OrderDto orderDto = null;

        // Act
        var result = _orderController.Post(orderDto);

        // Assert
        Assert.IsInstanceOf<BadRequestObjectResult>(result);
        var badRequest = result as BadRequestObjectResult;
        Assert.AreEqual("Order data is required.", badRequest.Value);

    }

    [Test]
    public void CreatesNewOrder()
    {
        // Arrange
        var orderDto = new OrderDto
        {
            OrderLines = new List<OrderLineDto>
                {
                    new OrderLineDto
                    {
                        SaleItem = new SaleItemDto { Id = 0, Name = "TestItem", Category = "hvede", Description = "God kvalitet", Price = 10, Stock = 1 },
                        Amount = 2
                    }
                }
        };

        // Act
        var result = _orderController.Post(orderDto);

        // Assert
        Assert.IsInstanceOf<CreatedAtActionResult>(result);
        var createdResult = result as CreatedAtActionResult;
        Assert.IsNotNull(createdResult);
    }


}