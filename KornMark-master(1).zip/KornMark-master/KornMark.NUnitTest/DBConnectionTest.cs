﻿using KornMark.DAL.DAO;
using NUnit.Framework;
using System.Data.SqlClient;
using System.Linq;

namespace UnitTestProject;

[TestFixture] // Marks this class as a test fixture
public class DBConnectionTest
{
    //private readonly string _connectionString = "YourConnectionStringHere"; // Replace with your actual connection string
    private readonly string _connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=KornMark;Integrated Security=True"; // localhost

    // Helper class to test the database connection
    private class TestDatabaseConnection
    {
        private readonly string _connectionString;

        public TestDatabaseConnection(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void TestConnection()
        {
            using var connection = new SqlConnection(_connectionString);
            connection.Open(); // Attempt to open the connection
        }
    }

    // Test to verify that the database connection can be opened
    [Test]
    public void TestConnection_ShouldConnectSuccessfully()
    {
        // Arrange
        var dao = new TestDatabaseConnection(_connectionString);

        // Act & Assert
        Assert.DoesNotThrow(() => dao.TestConnection(), "Connection failed.");
    }

    // Test to verify that the SaleItemsDAO can retrieve sale items
    [Test]
    public void GetSaleItems_ShouldReturnItems()
    {
        // Arrange
        var dao = new SaleItemsDAO(_connectionString);

        // Act
        var saleItems = dao.GetSaleItems();

        // Assert
        Assert.IsNotNull(saleItems, "Sale items list is null.");
        Assert.IsTrue(saleItems.Any(), "No sale items returned.");
    }
}
