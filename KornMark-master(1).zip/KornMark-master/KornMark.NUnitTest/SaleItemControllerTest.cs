﻿using KornMark.DAL.DAO;
using KornMark.WebAPI.Controllers;
using KornMark.WebAPI.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KornMark.NUnitTest;

public class SaleItemControllerTest
{
    private readonly string _connectionString = "Server=hildur.ucn.dk,1433; Database=DMA-CSD-S233_10503086; User Id=DMA-CSD-S233_10503086; Password=Password1!;";

    private ISalesItemsDAO _salesItemsDAO;
    private SaleItemController _saleItemController;
    private IConfiguration _configuration;
    private RestClient _restClient;

    [SetUp]
    public void SetUp()
    {
        // 1. Manually build the IConfiguration object with a connection string
        var configData = new Dictionary<string, string>
            {
                { "ConnectionStrings:DefaultConnection", "Server=hildur.ucn.dk,1433; Database=DMA-CSD-S233_10503086; User Id=DMA-CSD-S233_10503086; Password=Password1!;" }
            };

        _configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(configData)
            .Build();

        // 2. Initialize the controller with this configuration
        _saleItemController = new SaleItemController(_configuration);
    }


   

}
