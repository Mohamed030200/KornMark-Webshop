using NUnit.Framework;
using KornMark.DAL.DAO;
using System;
using System.Data;
using System.Data.SqlClient;

namespace KornMark.Tests
{
    [TestFixture]
    public class OrderDAOTests
    {
        private OrderDAO _orderDao;
        private string _connectionString;

        [SetUp]
        public void SetUp()
        {
            // Setup connection string to your test database (local DB for example)
            _connectionString = "Server=localhost;Database=KornMark;Integrated Security=True;"; // Change to your test DB

        }

        [Test]
        public void Insert_ShouldInsertOrder_WhenItemIsInStock()
        {
            // Arrange: Create a new order
            var order = new Order
            {
                TotalPrice = 100,
                Date = DateTime.Now
            };

            // Act: Insert the order into the database
            int orderNumber = _orderDao.Insert(order);

            // Assert: Check if the order was inserted successfully
            Assert.AreNotEqual(-1, orderNumber, "Order insertion failed. Item might be out of stock.");
        }

        [Test]
        public void Insert_ShouldRollback_WhenItemIsOutOfStock()
        {
            // Arrange: Create a new order with a sale item that is out of stock
            var order = new Order
            {
                TotalPrice = 100,
                Date = DateTime.Now
            };

            // Ensure that the stock check query returns false (item out of stock)
            // You would need to have the stock status set up accordingly in your test database.

            // Act: Attempt to insert the order into the database
            int orderNumber = _orderDao.Insert(order);

            // Assert: Ensure that no order was inserted
            Assert.AreEqual(-1, orderNumber, "Order should not have been inserted due to out-of-stock item.");
        }
    }
}

